package com.android.messaging.receiver;

import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.util.Log;

public class OdmSzReceiver extends BroadcastReceiver {
	  
      @Override
      public void onReceive(Context context, Intent intent) {
             Log.i("OdmSzTools", "OdmSzReceiver.onReceive intent:"+intent.getAction());
             if("android.provider.Telephony.ODMSZ_MMS_SMS_UPDATE".equals(intent.getAction())){
                String type = intent.getStringExtra("type");
                String id = intent.getStringExtra("id");
                String read = intent.getStringExtra("read");
                Log.i("OdmSzTools","ODMSZ_MMS_SMS_UPDATE type="+type+" id="+id+" read="+read);
                ContentValues values = new ContentValues();
                values.put("read", read);
                values.put("seen", "1");
                int updateRet = -1;
                if("sms".equals(type)){
                    updateRet = context.getContentResolver().update(Uri.parse("content://sms/inbox"), values, "_id=?", new String[]{id});
                }else if("mms".equals(type)){
                    updateRet = context.getContentResolver().update(Uri.parse("content://mms/inbox"), values, "_id=?", new String[]{id});
                }
                Log.i("OdmSz","ODMSZ_MMS_SMS_UPDATE updateRet="+updateRet);
             }else if ("android.intent.action.BOOT_COMPLETED".equals(intent.getAction())){
         		//注册监听广播
         		IntentFilter odmszfilter = new IntentFilter();
         		odmszfilter.addAction("android.provider.Telephony.ODMSZ_MMS_SMS_UPDATE");
         		OdmSzReceiver odmSzReceiver = new OdmSzReceiver();
         		context.getApplicationContext().registerReceiver(odmSzReceiver, odmszfilter);
         		Log.i("OdmSz", "OdmSzReceiver.registerReceiver ");
             }

      };
	
}

