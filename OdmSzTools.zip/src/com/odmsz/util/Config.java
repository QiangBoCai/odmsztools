/******************************************************************************
 @file    Config.java
---------------------------------------------------------------------------
        Copyright (c) 2015 net263 Technologies, Inc.  All Rights Reserved.
        net263 Technologies Proprietary and Confidential.
 ---------------------------------------------------------------------------
 ******************************************************************************/


package com.odmsz.util;

import android.os.Environment;

public final class Config 
{

	public static final String EXTERNAl_SD_PATH = Environment
			.getExternalStorageDirectory().getPath();
	public static final String SOFTSIM_LOG_PATH = EXTERNAl_SD_PATH+"/odmszlog.txt";
}
