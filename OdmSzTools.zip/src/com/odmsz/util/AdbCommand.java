package com.odmsz.util;
 
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
 
/*
 * adb 命令方法集合类
 */
public class AdbCommand {
//    private static  BufferedReader mReader = null;
//    private static boolean mRunning = true;
//    static String cmds = null;
//    private String mPID;
//    private static FileOutputStream out = null;
	private Process process =null;
	private StringBuffer output =null;
    private BufferedReader reader = null;
	public String exec(String cmds) {
        try {
            process = Runtime.getRuntime().exec(cmds);
            reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()),512);
//            int read;
//          //  char[] buffer = new char[4096];
//            char[] buffer = new char[2048];
//            
            StringBuffer output = new StringBuffer();
//            while ((read = reader.read(buffer)) > 0) {
//                output.append(buffer, 0, read);
//            }
            String line = null;
            int time =0;
            while ((line = reader.readLine()) != null) {
                if (line.length() == 0) {
                    continue;
                }
                time++;
                output.append(line);
                LogUtils.print("exec ret:"+line+" time:"+time);
            }
//            reader.close();
           // LogUtils.print("waitFor");
            process.waitFor();
            LogUtils.print("output.toString:"+output.toString());
            return output.toString();
        } catch (Exception e) {
        	e.printStackTrace();
        	 LogUtils.print("exec ret:"+e.getMessage());
        	return cmds;
        	//            throw new RuntimeException(e);
        }finally {
          if (process != null) {
        	process.destroy();
        	process = null;
          }
          if(reader !=null){
        	 try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
        	  reader = null;
          }
          if (output != null) {
            output = null;
          }
          
        }
        

//		try {
//			process = Runtime.getRuntime().exec(cmds);
//            mReader = new BufferedReader(new InputStreamReader(
//            		process.getInputStream()), 1024);
//            String line = null;
//            while (mRunning && (line = mReader.readLine()) != null) {
//                if (!mRunning) {
//                    break;
//                }
//                if (line.length() == 0) {
//                    continue;
//                }
//                if (out != null ) {//&& line.contains(mPID)
//                    out.write((line + "\n").getBytes());
//                }
//            }
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            if (process != null) {
//            	process.destroy();
//            	process = null;
//            }
//            if (mReader != null) {
//                try {
//                    mReader.close();
//                    mReader = null;
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//            if (out != null) {
//                try {
//                    out.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//                out = null;
//            }
//        }
//		return cmds;
    }
	
	public String execShell(String cmds) {
        try {
            process = Runtime.getRuntime().exec(new String[]{"/system/bin/sh","-c",cmds});
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));
            int read;
            char[] buffer = new char[4096];
            StringBuffer output = new StringBuffer();
            while ((read = reader.read(buffer)) > 0) {
                output.append(buffer, 0, read);
            }
            reader.close();
            process.waitFor();
            return output.toString();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }finally {
          if (process != null) {
        	process.destroy();
        	process = null;
          }
          if (output != null) {
            
            output = null;
          }
        }
	}
 
}