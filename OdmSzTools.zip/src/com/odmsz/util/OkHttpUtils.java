package com.odmsz.util;

import java.util.concurrent.TimeUnit;

import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class OkHttpUtils {
	    public static String TAG="OkHttpUtils";
	    private static volatile OkHttpUtils sInstance;
	    private OkHttpClient mOkHttpClient;
	    // 超时时间
	    public static final int TIMEOUT = 1000 * 60;

	    //json请求
	    public static final MediaType JSON = MediaType
	            .parse("application/json; charset=utf-8");


	    public OkHttpUtils() {

	      	mOkHttpClient = new OkHttpClient();

	        // 设置超时时间
	    	mOkHttpClient.newBuilder().connectTimeout(TIMEOUT, TimeUnit.SECONDS)
	                .writeTimeout(TIMEOUT, TimeUnit.SECONDS)
	                .readTimeout(TIMEOUT, TimeUnit.SECONDS).build();
	    }
	    
	    public OkHttpClient getOkHttpClient() {
	        return mOkHttpClient;
	    }
	    
	    public static OkHttpUtils getInstance() {
	        if (sInstance == null)
	        {
	            synchronized (OkHttpUtils.class)
	            {
	                if (sInstance == null)
	                {
	                	sInstance = new OkHttpUtils();
	                }
	            }
	        }
	        return sInstance;
	    }
	    


	    /**
	     * post请求，json数据为body
	     * 
	     * @param url
	     * @param json
	     * @param callback
	     */
	    public void postJson(String url, String json, final Callback callback) {

	        RequestBody body = RequestBody.create(JSON, json);
	        Request request = new Request.Builder()
	        		.url(url)
	        		.header("Content-Length", String.valueOf(json.length()))
	        		.header("checkSum", MD5Util.encrypt(json+"0ACEAF99F9A59589E290FF05B904E6D6"))
	        		.post(body).build();
	        if (null != callback) {
	            mOkHttpClient.newCall(request).enqueue(callback);
	        }

	      

	    }




}
