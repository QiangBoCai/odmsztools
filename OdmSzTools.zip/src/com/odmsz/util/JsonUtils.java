package com.odmsz.util;



import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.JSONLibDataFormatSerializer;
import com.alibaba.fastjson.serializer.SerializeConfig;
import com.alibaba.fastjson.serializer.SerializerFeature;

public class JsonUtils 
{

	private static final SerializeConfig config ;
	
	static
	{
		config = new SerializeConfig();
		//使用json-lib 兼容的日期输出格式
		config.put(java.util.Date.class, new JSONLibDataFormatSerializer());
		config.put(java.sql.Date.class, new JSONLibDataFormatSerializer());
	} 

	private static final SerializerFeature[] features = 
	{
		
		SerializerFeature.WriteMapNullValue, // 输出空置字段  
        SerializerFeature.WriteNullListAsEmpty, // list字段如果为null，输出为[]，而不是null  
        SerializerFeature.WriteNullNumberAsZero, // 数值字段如果为null，输出为0，而不是null  
        SerializerFeature.WriteNullBooleanAsFalse, // Boolean字段如果为null，输出为false，而不是null  
        SerializerFeature.WriteNullStringAsEmpty // 字符类型字段如果为null，输出为""，而不是null  
	};

	
	/*
	 * 
	 *  javabean 转换成jsonSring
	 * */
	
	public static String toJSONString(Object javaBean)
	{
		
		return JSON.toJSONString(javaBean,config,features) ;
	}
	
	/*
	 * 
	 *  javabean 转换成jsonObject
	 * */
	
	public static JSONObject toJSONObject(Object javaBean)
	{
		return (JSONObject) JSON.toJSON(javaBean);
	}
	/*
	 * 1.2 jsonString  转换成 泛型javabean 
	 * */
	
	public static <T>T toJavaBean(String jsonString , Class<T> cls)
	{
		
		return JSON.parseObject(jsonString,cls);
	}
	
	/*
	 * jsonString 转换成JSONObject
	 * */
	public static JSONObject toJSONObject(String jsonString )
	{
		return JSON.parseObject(jsonString);
	}
	
	
	
	
	/*
	 * jsonString > List<T>
	 * */
	public static <T> List<T> toList(String jsonString, Class<T> cls)
	{
		
		return JSON.parseArray(jsonString, cls);
	}

	

	/*
	 * jsonString >  Map<String,Object>>
	 * */
	public static Map<String,Object> toMap(String jsonString)
	{
		Map<String,Object> map = JSON.parseObject(jsonString);
		return map;
	}

	
	/*
	 *   Map<String,Object>>  >jsonString 
	 * */
	public static String toJsonString(Map<String, Object> map)
	{
		String jsonString= JSON.toJSONString(map);
		return jsonString;
	}
	
	
	
	public static boolean writeJsonString(String filePath,String jsonString) throws IOException 
	{
		boolean ret = false;
		if(jsonString == null )
		{
			jsonString ="";
		}
		if(filePath!=null)
		{
		    File file = new File(filePath);  
		    FileOutputStream fileOutputSteam = null;
		    OutputStreamWriter out = null;
		    if (!file.isFile())
	        {  
		    	try {
					file.createNewFile();
				} catch (IOException e) {
					e.printStackTrace();
				}
	            
	        } 			
		    try 
            {
				fileOutputSteam = new FileOutputStream(file);
	            out = new OutputStreamWriter(fileOutputSteam,"UTF-8");
	            out.append(jsonString);  
	            ret = true ;
            } catch (IOException e) {
				e.printStackTrace();
			}finally
			{	
				out.close();
				fileOutputSteam.close();
			
			}

		}
		return ret;
	}
	
	/**
	 * 从文件中读取jsonString
	 * @param jsonFilePath
	 * @return
	 * @throws IOException
	 */
	public static String getJsonString(String jsonFilePath) throws IOException
	{
		String laststr = "";
		if(jsonFilePath!=null)
		{
			BufferedReader reader = null ;

			FileInputStream fileInputStream = null;

			InputStreamReader inputStreamReader = null;
			try 
			{
				fileInputStream = new FileInputStream(jsonFilePath);
				inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
			
				reader = new BufferedReader(inputStreamReader);
				String tempString = null;
				while((tempString = reader.readLine()) != null)
				{
					laststr += tempString;
				}
			}
			catch (FileNotFoundException e)
			{
				e.printStackTrace();
			} 
			catch (UnsupportedEncodingException e) 
			{
				e.printStackTrace();
			}
		    catch (IOException e)
		    {
		    	e.printStackTrace();
		    }finally
			{
				inputStreamReader.close();
				fileInputStream.close();
				
			}
		}
		return laststr;

	}
}
