package com.odmsz.util;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.params.ConnRouteParams;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;

import com.odmsz.control.OdmSzControlManager;
import com.odmsz.receiver.OdmSzControlReceiver;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.net.http.AndroidHttpClient;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.widget.Toast;
import androidx.appcompat.mms.pdu.CharacterSets;
import androidx.appcompat.mms.pdu.EncodedStringValue;
import androidx.appcompat.mms.pdu.PduBody;
import androidx.appcompat.mms.pdu.PduComposer;
import androidx.appcompat.mms.pdu.PduPart;
import androidx.appcompat.mms.pdu.SendReq;

import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class MmSUtils {
	private static final String TAG = "MmSUtils";
	// 电信彩信中心url，代理，端口
	public static final String mmscUrl_ct = "http://mmsc.vnet.mobi";
	public static final String mmsProxy_ct = "10.0.0.200";
	// 移动彩信中心url，代理，端口
	public static final String mmscUrl_cm = "http://mmsc.monternet.com";
	public static final String mmsProxy_cm = "010.000.000.172";
	// 联通彩信中心url，代理，端口
	public static String mmscUrl_uni = "http://mmsc.vnet.mobi";
	public static String mmsProxy_uni = "10.0.0.172";
	private static String HDR_VALUE_ACCEPT_LANGUAGE = "";
	private static final String HDR_KEY_ACCEPT = "Accept";
	private static final String HDR_KEY_ACCEPT_LANGUAGE = "Accept-Language";
	private static final String HDR_VALUE_ACCEPT = "*/*, application/vnd.wap.mms-message, application/vnd.wap.sic";
	final static List<String> reason = new ArrayList<String>();
	private static  String APN_NET_ID = null;
	/**
	 * 发彩信接口 
	 * @param context
	 * @param phone 手机号
	 * @param subject 主题
 	 * @param text	文字
	 * @param imagePath 图片路径	
	 * @param audioPath	音频路径
	 */
	public static void sendMms(final Context context,final String phone,final String subject,
			final String text,final String imagePath,final String audioPath) {
		reason.clear();
		SendReq sendRequest = new SendReq();
		if(!TextUtils.isEmpty(subject)){
			EncodedStringValue[] sub = EncodedStringValue.extract(subject);
			if (sub != null && sub.length > 0) {
				sendRequest.setSubject(sub[0]);
			}
		}

		EncodedStringValue[] phoneNumbers = EncodedStringValue
				.extract(phone);
		if (phoneNumbers != null && phoneNumbers.length > 0) {
			sendRequest.addTo(phoneNumbers[0]);
		}
		PduBody pduBody = new PduBody();
		if(!TextUtils.isEmpty(text)){
			PduPart partPdu3 = new PduPart();
			partPdu3.setCharset(CharacterSets.UTF_8);
			partPdu3.setName("mms_text.txt".getBytes());
			partPdu3.setContentType("text/plain".getBytes());
			partPdu3.setData(text.getBytes());
			pduBody.addPart(partPdu3);
		}
		if(!TextUtils.isEmpty(imagePath)){
			PduPart partPdu = new PduPart();
			partPdu.setCharset(CharacterSets.UTF_8);
			partPdu.setName("camera.jpg".getBytes());
			partPdu.setContentType("image/png".getBytes());
//		partPdu.setDataUri(Uri.parse("file:///sdcard//1.jpeg"));
			partPdu.setDataUri(Uri.fromFile(new File(imagePath)));
			pduBody.addPart(partPdu);
		}
		if(!TextUtils.isEmpty(audioPath)){
			PduPart partPdu2 = new PduPart();
			partPdu2.setCharset(CharacterSets.UTF_8);
			partPdu2.setName("speech_test.amr".getBytes());
			partPdu2.setContentType("audio/amr".getBytes());
			// partPdu2.setContentType("audio/amr-wb".getBytes());
//			partPdu2.setDataUri(Uri.parse("file:///sdcard//1.amr"));
			partPdu2.setDataUri(Uri.fromFile(new File(audioPath)));
			pduBody.addPart(partPdu2);
		}
 
		sendRequest.setBody(pduBody);
		final PduComposer composer = new PduComposer(context, sendRequest);
		final byte[] bytesToSend = composer.make();
		LogUtils.print(TAG+ "  bytesToSend："+bytesToSend);
		
		final List<String> list = getSimMNC(context);

		Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				//因为在切换apn过程中需要一定时间，所以需要加上一个重试操作
				int retry = 0;
				do {
					LogUtils.print(TAG+ "重试次数："+(retry+1));
					try {
						if (sendMMS(list, context, bytesToSend)) {
							OdmSzControlManager.mHandler.post(new Runnable() {
 
								@Override
								public void run() {
//									Toast.makeText(context, "彩信发送成功!",
//											Toast.LENGTH_SHORT).show();
									 //发送广播给上层APP
							    	Intent appIntent = new Intent();
							    	appIntent.putExtra("result", "彩信发送成功!");
						            appIntent.putExtra("phone",phone);
						            appIntent.putExtra("reason", reason.toString());
						            appIntent.putExtra("subject", subject);
						            appIntent.putExtra("text", text);
						            appIntent.putExtra("imagePath", imagePath);
						            appIntent.putExtra("audioPath", audioPath);
							        appIntent.setAction(OdmSzControlReceiver.ODMSZ_MMS_SENT_ACTION);
							    	context.sendBroadcast(appIntent);
							    	LogUtils.print("result:"+"彩信发送成功!"+
							    			"\nphone:"+phone+
							    			"\nsubject:"+subject+
							    			"\ntext:"+text+
							    			"\nimagePath:"+imagePath+
							    			"\naudioPath:"+audioPath+
							    			"");
							    	reason.clear();
								
								}
							});
							return;
						}
						retry++;
						Thread.sleep(3000);
					} catch (Exception e) {
						e.printStackTrace();
					}
				} while (retry < 20);
				OdmSzControlManager.mHandler.post(new Runnable() {
					@Override
					public void run() {
//						Toast.makeText(context, "彩信发送失败！", Toast.LENGTH_SHORT).show();
						 //发送广播给上层APP
				    	Intent appIntent = new Intent();
				    	appIntent.putExtra("result", "彩信发送失败!");
				    	appIntent.putExtra("reason", reason.toString());
			            appIntent.putExtra("phone",phone);
			            appIntent.putExtra("subject", subject);
			            appIntent.putExtra("text", text);
			            appIntent.putExtra("imagePath", imagePath);
			            appIntent.putExtra("audioPath", audioPath);
				        appIntent.setAction(OdmSzControlReceiver.ODMSZ_MMS_SENT_ACTION);
				    	context.sendBroadcast(appIntent);
				    	LogUtils.print("result:"+"彩信发送失败!"+
				    			"\nphone:"+phone+
				    			"\nsubject:"+subject+
				    			"\ntext:"+text+
				    			"\nimagePath:"+imagePath+
				    			"\naudioPath:"+audioPath+
				    			"");
				    	reason.clear();
					}
				});
				
			}
		});
		t.start();
 
	}
	private static boolean sendMMS(List<String> list,final Context context, byte[] pdu) throws Exception {
		// HDR_AVLUE_ACCEPT_LANGUAGE = getHttpAcceptLanguage();
		if(list==null){
			OdmSzControlManager.mHandler.post(new Runnable() {
				
				@Override
				public void run() {
					Toast.makeText(context, "找不到sim卡", Toast.LENGTH_SHORT).show();
				}
			});
			return false;
		}
		String mmsUrl = (String) list.get(0);
		String mmsProxy = (String) list.get(1);
		AndroidHttpClient client = null;
		try {
			URI hostUrl = new URI(mmsUrl);
			HttpHost target = new HttpHost(hostUrl.getHost(),
					hostUrl.getPort(), HttpHost.DEFAULT_SCHEME_NAME);
			client = AndroidHttpClient.newInstance("Android-Mms/2.0");
			HttpPost post = new HttpPost(mmsUrl);
			ByteArrayEntity entity = new ByteArrayEntity(pdu);
			entity.setContentType("application/vnd.wap.mms-message");
			post.setEntity(entity);
			post.addHeader(HDR_KEY_ACCEPT, HDR_VALUE_ACCEPT);
			post.addHeader(HDR_KEY_ACCEPT_LANGUAGE, HDR_VALUE_ACCEPT_LANGUAGE);
 
			HttpParams params = client.getParams();
			HttpProtocolParams.setContentCharset(params, "UTF-8");
 
			ConnRouteParams.setDefaultProxy(params, new HttpHost(mmsProxy,
					80));
			HttpResponse response = client.execute(target, post);
			
			StatusLine status = response.getStatusLine();
			LogUtils.print("status : " + status.getStatusCode());
			if (status.getStatusCode() != 200) {
				throw new IOException("HTTP error: " + status.getReasonPhrase());
			}
			//彩信发送完毕后检查是否需要把接入点切换回来
			if(null!=APN_NET_ID){
				setApn(context,APN_NET_ID);
			}
			return true;
 
		} catch (Exception e) {
			e.printStackTrace();
			if(!reason.contains(e.getMessage())){
				reason.add(e.getMessage());
			}
			
			LogUtils.print( "sendMMS  彩信发送失败："+e.getMessage());
			//发送失败处理
		}finally{
			if(client!=null){
				client.close();
				LogUtils.print("client close");
			}
		}
		return false;
	}
	
	private static String getApn(Context context){
		ContentResolver resoler = context.getContentResolver();
		String[] projection = new String[]{"_id"};
		Cursor cur = resoler.query(Uri.parse("content://telephony/carriers/preferapn"),projection, null, null, null);
		String apnId = null;
		if(cur!=null&&cur.moveToFirst()){
			do {
				apnId = cur.getString(cur.getColumnIndex("_id"));
			} while (cur.moveToNext());
		}
		return apnId;
	}
	/**
	 * 设置接入点
	 * @param id
	 */
	private static void setApn(Context context ,String id){
		Uri uri = Uri.parse("content://telephony/carriers/preferapn");   
		ContentResolver resolver = context.getContentResolver();  
		ContentValues values = new ContentValues();  
		values.put("apn_id", id);  
		resolver.update(uri, values, null, null);
	}

	/**
	 * 取到wap接入點的id
	 * @return
	 */
	private static String getWapApnId(Context context){
		ContentResolver contentResolver = context.getContentResolver();
		String[] projection = new String[]{"_id","proxy"};
		Cursor cur = contentResolver.query(Uri.parse("content://telephony/carriers"), projection, "current = 1", null, null);
		if(cur!=null&&cur.moveToFirst()){
			do {
				String id = cur.getString(0);
				String proxy = cur.getString(1);
				if(!TextUtils.isEmpty(proxy)){
					return id;
				}
			} while (cur.moveToNext());
		}
		return null;
	}
	
	private static boolean shouldChangeApn(final Context context){
		
		final String wapId = getWapApnId(context);
		String apnId = getApn(context);
		//若当前apn不是wap，则切换至wap
		if(!wapId.equals(apnId)){
			APN_NET_ID = apnId;
			setApn(context,wapId);
			//切换apn需要一定时间，先让等待2秒
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return true;
		}
		return false;
	}
	
	private static List<String> getSimMNC(Context context){
		TelephonyManager telManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE); 
		String imsi = telManager.getSubscriberId(); 
		if(imsi!=null){ 
			ArrayList<String> list = new ArrayList<String>();
			if(imsi.startsWith("46000") ||imsi.startsWith("46002")){ 
				//因为移动网络编号46000下的IMSI已经用完，所以虚拟了一个46002编号，134/159号段使用了此编号 
				//中国移动 
				list.add(mmscUrl_cm);
				list.add(mmsProxy_cm);
			}else if(imsi.startsWith("46001")){ 
				//中国联通 
				list.add(mmscUrl_uni);
				list.add(mmsProxy_uni);
			}else if(imsi.startsWith("46003")){ 
				//中国电信 
				list.add(mmscUrl_ct);
				list.add(mmsProxy_ct);
			} 
			shouldChangeApn(context);
			return list;
		}
		return null;
	}
}
