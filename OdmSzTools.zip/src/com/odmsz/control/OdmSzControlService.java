
package com.odmsz.control;

import java.util.List;

import android.app.ActivityManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.session.PlaybackState.CustomAction;
import android.os.Binder;
import android.os.IBinder;
import android.os.RemoteException;
import android.telephony.TelephonyManager;



import com.odmsz.control.OdmSzControlTelephony;
import com.odmsz.receiver.OdmSzControlReceiver;
import com.odmsz.util.LogUtils;

public class OdmSzControlService extends Service {
	

    
    public  static boolean mServiceOn = false;

    private final String VERSION = "1.0.10.1_20231026_1811";
    public Context mContext;
	private static OdmSzControlTelephony odmSzControlTelephony = null;
    private OdmSzControlReceiver odmSzControlReceiver = null;
    private OdmSzControlManager odmSzControlManager = null;
    private OdmSzJniSession odmSzJniSession = null;
    public static final String ACTION = "com.odmsz.control.OdmSzControlService.start";
    

    @Override
    public void onCreate() {
		super.onCreate();
		mContext=this;
		LogUtils.d( "OdmSzControlService onCreate()+Version() ="+VERSION);
		odmSzJniSession = new OdmSzJniSession();
		odmSzControlTelephony = new OdmSzControlTelephony(mContext);
		odmSzControlManager = new OdmSzControlManager(this,mContext, odmSzControlTelephony,odmSzJniSession);

		//注册监听广播
		IntentFilter odmszfilter = new IntentFilter();
		odmszfilter.addAction(OdmSzControlReceiver.ACTION_AIRPLANE_MODE_CHANGED);
		odmszfilter.addAction(OdmSzControlReceiver.ACTION_SMS_RECEIVED);
		odmszfilter.addAction(OdmSzControlReceiver.ACTION_SEND_SMS);
		odmszfilter.addAction(OdmSzControlReceiver.ACTION_DELIVERY_SMS);
		odmszfilter.addAction(TelephonyManager.ACTION_PHONE_STATE_CHANGED);
//		odmszfilter.addAction(OdmSzControlReceiver.ACTION_SIM_STATE_CHANGED);
//		odmszfilter.addAction(Intent.ACTION_SCREEN_ON);
//		odmszfilter.addAction(Intent.ACTION_SCREEN_OFF);
//		odmszfilter.addAction(OdmSzControlReceiver.ACTION_PRECISE_CALL_STATE); 
//		odmszfilter.addAction(Intent.ACTION_BATTERY_CHANGED);
		 
		odmSzControlReceiver = new OdmSzControlReceiver();
		mContext.registerReceiver(odmSzControlReceiver, odmszfilter);
		
	    mServiceOn = true;
	
    }
	
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
    	LogUtils.d( "OdmSzControlService onStartCommand()");
    	return super.onStartCommand(intent, flags, startId);
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        LogUtils.d( "OdmSzControlService onBind()");
        return mBinder;
    }
    
    @Override
    public boolean onUnbind(Intent intent) {
    	LogUtils.d( "OdmSzControlService onUnbind()");
    	return super.onUnbind(intent);
    }
    
    @Override
    public void onDestroy() {
        LogUtils.d( " OdmSzControlService onDestroy()");
        mServiceOn=false;


		if(mContext!=null){
			ActivityManager am= (ActivityManager)mContext.getSystemService(Context.ACTIVITY_SERVICE);
			am.forceStopPackage("com.odmsz.control");
		}
    	super.onDestroy();
    	return;
    }

    
   

    /**
    *  IOdmSzControlService.aidl对应接口的实现
    * 
    */
    private final IOdmSzControlService.Stub mBinder = new IOdmSzControlService.Stub(){

		@Override
		public String initialize(String token) {
		    long identity = Binder.clearCallingIdentity();
            try {
            	
            }catch (Exception e){
                e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
	            
			return "odmsz";
		}

		@Override
		public String getVersion(String token) {
		    long identity = Binder.clearCallingIdentity();
            try {
            	
            }catch (Exception e){
                e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
	            
			return VERSION;
		}

		@Override
		public boolean call(String token, String number){
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
    			odmSzControlManager.call(number);
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}
		 /**
		  * 无条件
	     * Indicates the call forwarding reason is "unconditional".
	     */
	    public static final int REASON_UNCONDITIONAL = 0;

	    /**
	     * 被叫忙
	     * Indicates the call forwarding status is "busy".
	     */
	    public static final int REASON_BUSY = 1;

	    /**
	     * 无应答
	     * Indicates the call forwarding reason is "no reply".
	     */
	    public static final int REASON_NO_REPLY = 2;

	    /**
	     * 不可及
	     * Indicates the call forwarding reason is "not reachable".
	     */
	    public static final int REASON_NOT_REACHABLE = 3;

	    /**
	     * Indicates the call forwarding reason is "all", for setting all call forwarding reasons
	     * simultaneously (unconditional, busy, no reply, and not reachable).
	     */
	    public static final int REASON_ALL = 4;

	    /**
	     * Indicates the call forwarding reason is "all_conditional", for setting all conditional call
	     * forwarding reasons simultaneously (busy, no reply, and not reachable).
	     */
	    public static final int REASON_ALL_CONDITIONAL = 5;
	    
		@Override
		public CallForwardingInfo getCallForwarding(String token,
				int callForwardingReason) {
			CallForwardingInfo callForwardingInfo = null;
		    long identity = Binder.clearCallingIdentity();
            try {
            	callForwardingInfo = odmSzControlManager.getCallForwarding(callForwardingReason);
            }catch (Exception e){
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
              	
            }
            return callForwardingInfo;

		}

		@Override
		public boolean setCallForwarding(String token,CallForwardingInfo callForwardingInfo){
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
    			ret=odmSzControlManager.setCallForwarding(callForwardingInfo);
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}
		
		
		@Override
		public boolean acceptRingingCall(String token){
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
    			ret = odmSzControlManager.acceptRingingCall();
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		

		@Override
		public boolean endCall(String token) throws RemoteException {
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
    			ret = odmSzControlManager.endCall();
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public boolean sendTextMessage(String token, String destinationAddress,
				String scAddress, String message) throws RemoteException {
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
            	 odmSzControlManager.sendTextMessage(destinationAddress,scAddress,message);
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public int getPhoneType() throws RemoteException {
			int ret = 0;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" getPhoneType");
            	ret = odmSzControlManager.getPhoneType();
            }catch (Exception e){
            	ret = 0;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}


		@Override
		public int getCallWaitingStatus(String token){
			int ret = 0;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" getCallWaitingStatus");
            	ret = odmSzControlManager.getCallWaitingStatus();
            }catch (Exception e){
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public boolean setCallWaitingStatus(String token, boolean isEnable){
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" setCallWaitingStatus");
            	ret=odmSzControlManager.setCallWaitingStatus(isEnable);
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public boolean isRinging(String token) throws RemoteException {
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" isRinging");
            	ret=odmSzControlManager.isRinging();
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public boolean isInCall(String token) throws RemoteException {
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" isInCall");
            	ret=odmSzControlManager.isInCall();
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public boolean silenceRinger(String token) throws RemoteException {
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" silenceRinger");
            	ret=odmSzControlManager.silenceRinger();
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public int getPreferredNetwork(String token, int slot){
			int ret = -2;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" getPreferredNetwork");
            	ret=odmSzControlManager.getPreferredNetwork(slot);
            }catch (Exception e){
            	ret = -2;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public boolean setPreferredNetwork(String token,int slot, int networktype){
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" setPreferredNetwork");
            	ret=odmSzControlManager.setPreferredNetwork(slot,networktype);
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public boolean getAirPlaneModeStatus(String token){
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" getAirPlaneModeStatus");
            	ret=odmSzControlManager.getAirPlaneModeStatus();
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public boolean setAirPlaneMode(String token, boolean enable){
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" setAirPlaneMode");
            	odmSzControlManager.setAirPlaneMode(enable);
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public List<CellIdentity> getCellInfo(String token) throws RemoteException {
			List<CellIdentity> cellInfos = null;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" getCellInfo");
            	cellInfos = odmSzControlManager.getCellInfo();
            }catch (Exception e){
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return cellInfos;
		}

		@Override
		public int getSimState(String token) {
			int ret = 0;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" getSimState");
            	ret = odmSzControlManager.getSimState();
            }catch (Exception e){
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public boolean isDataRoamingEnabled(String token) {
			boolean ret = false;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" isDataRoamingEnabled");
            	ret=odmSzControlManager.isDataRoamingEnabled();
            }catch (Exception e){
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public boolean setDataRoamingEnabled(String token, boolean enable) {
			boolean ret = true;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" setDataRoamingEnabled");
            	odmSzControlManager.setDataRoamingEnabled(enable);
            }catch (Exception e){
            	ret = false;
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public int getServiceState(String token){

			int ret = 1;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" getServiceState");
            	ret=odmSzControlManager.getServiceState();
            }catch (Exception e){
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public String getServiceDomain(String token) {


			String  ret = "";
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" getServiceDomain");
            	ret=odmSzControlManager.getServiceDomain();
            }catch (Exception e){
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}


		@Override
		public boolean readSms(String token,long id,boolean update,int read){

			boolean  ret = false;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" readSms");
            	ret=odmSzControlManager.readSms(id,update,read);
            }catch (Exception e){
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

		@Override
		public boolean readMms(String token,long id,boolean update,int read){
			boolean  ret = false;
		    long identity = Binder.clearCallingIdentity();
            try {
            	LogUtils.print(" readMms");
            	ret=odmSzControlManager.readMms(id,update,read);
            }catch (Exception e){
            	e.printStackTrace();
            }finally {
              	Binder.restoreCallingIdentity(identity);
            }
			return ret;
		}

//		@Override
//		public boolean sendMmsImage(String token,String phone, String url) {
//			boolean  ret = true;
//		    long identity = Binder.clearCallingIdentity();
//            try {
//            	odmSzControlManager.sendMmsImage(phone,url);
//            }catch (Exception e){
//            	ret = false;
//            	e.printStackTrace();
//            }finally {
//              	Binder.restoreCallingIdentity(identity);
//            }
//			return ret;
//		}

		@Override
		public int playSound(String token, String file){
			int  ret = -1;
		    long identity = Binder.clearCallingIdentity();
	        try {
	        	LogUtils.print("control playSound file:"+file);
	        	ret=odmSzControlManager.playSound(file);
	        	LogUtils.print("control playSound ret:"+ret);
	        }catch (Exception e){
	        	ret=-1;
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
			return ret;
		}

		@Override
		public int stopSound(String token)  {
			int  ret = -1;
		    long identity = Binder.clearCallingIdentity();
	        try {
	        	
	        	LogUtils.print("control stopSound +");
	        	ret = odmSzControlManager.stopSound();
	        	LogUtils.print("control stopSound ret:"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
			return ret;
		}

		@Override
		public String exeCmd(String token, String cmd,boolean isSync) throws RemoteException {
			String  ret = "";
		    long identity = Binder.clearCallingIdentity();
	        try {
	        	LogUtils.print(" exeCmd cmd:"+cmd);
	        	ret = odmSzControlManager.exeCmd(cmd,isSync);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
			return ret;
		}

		@Override
		public boolean sendMms(String token, String phone, String subject,
				String text, String imagePath, String audioPath){
			boolean  ret = true;
		    long identity = Binder.clearCallingIdentity();
	        try {
	        	LogUtils.print(" sendMms");
	        	odmSzControlManager.sendMms(phone, subject,
	    				text, imagePath, audioPath);
	        }catch (Exception e){
	        	ret = false;
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
			return ret;
		}

		@Override
		public int hold(String token, int hold) throws RemoteException {
			
			int ret = 0;
		    long identity = Binder.clearCallingIdentity();
	        try {
	        	Intent intent = new Intent();  
	        	intent.putExtra("hold", hold);
	        	intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);  
	        	intent.setAction("com.android.incallui.ACTION_ODMSZ_HOLD");  
	        	mContext.sendBroadcast(intent); 
	        	LogUtils.print("sendBroadcast  hold:"+hold);
	        }catch (Exception e){
	        	ret = -1;
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public boolean restartModem(String token) throws RemoteException {
			boolean  ret = true;
		    long identity = Binder.clearCallingIdentity();
	        try {
	        	LogUtils.print(" restartModem");
	        	odmSzControlManager.restartModem();
	        }catch (Exception e){
	        	ret = false;
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
			return ret;
		}

		@Override
		public int callForward(String token, String forwardNumber){
			int ret = 0;
		    long identity = Binder.clearCallingIdentity();
	        try {
	        	LogUtils.print(" callForward");
	        	odmSzControlManager.callForward(forwardNumber); 
	        	LogUtils.print("callForward  :"+forwardNumber);
	        }catch (Exception e){
	        	ret = -1;
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public void sendUssdRequest(String token, String number){
			long identity = Binder.clearCallingIdentity();
			try {
				LogUtils.print(" sendUssdRequest");
	        	odmSzControlManager.sendUssdRequest(number); 
	        	LogUtils.print("sendUssdRequest  :"+number);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
		}

		@Override
		public String getCurrentImsi(String token){
			String ret = "";
		    long identity = Binder.clearCallingIdentity();
	        try {
	        	LogUtils.print(" getCurrentImsi");
	        	ret = odmSzControlManager.getCurrentImsi(); 
	        	LogUtils.print("getCurrentImsi  :"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public String getCurrentPhoneNumber(String token){
			String ret = "";
		    long identity = Binder.clearCallingIdentity();
	        try {
	        	LogUtils.print(" getCurrentPhoneNumber");
	        	ret = odmSzControlManager.getCurrentPhoneNumber(); 
	        	LogUtils.print("getCurrentPhoneNumber  :"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public int getCallState(String token){
			int ret = 0;
		    long identity = Binder.clearCallingIdentity();
	        try {
	        	LogUtils.print(" getCallState");
	        	ret = odmSzControlManager.getCallState(); 
	        	LogUtils.print("getCallState  :"+ret);
	        }catch (Exception e){
	        	ret = -1;
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public void updateMms(String token, long id, String read){
		    long identity = Binder.clearCallingIdentity();
	        try {
	        	LogUtils.print(" updateMms");
	        	odmSzControlManager.updateMms(id,read); 
	        	LogUtils.print("updateMms  ");
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
		}

		@Override
		public void updateSms(String token, long id, String read){
		    long identity = Binder.clearCallingIdentity();
	        try {
	        	LogUtils.print(" updateSms");
	        	odmSzControlManager.updateSms(id,read); 
	        	LogUtils.print("updateSms  ");
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
		}

		@Override
		public void shutdown(String token,boolean tag){
			long identity = Binder.clearCallingIdentity();
	        try {
	        	LogUtils.print(" shutdown");
	        	odmSzControlManager.shutdown(tag); 
	        	LogUtils.print("shutdown  tag:"+tag);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
			
		}

		@Override
		public void reboot(String token,int nowait,int interval,int window){
			long identity = Binder.clearCallingIdentity();
	        try {
	        	LogUtils.print(" reboot");
	        	odmSzControlManager.reboot(nowait,interval,window); 
	        	LogUtils.print("reboot  nowait:"+nowait+" interval:"+interval+" window:"+window);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
		}

		@Override
		public String getSmscAddress(String token){
			long identity = Binder.clearCallingIdentity();
			String ret = "";
	        try {
	        	LogUtils.print(" getSmscAddress");
	        	ret = odmSzControlManager.getSmscAddress(); 
	        	LogUtils.print(" getSmscAddress:"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public boolean setSmscAddress(String token, String smscAddress){
			long identity = Binder.clearCallingIdentity();
			boolean  ret = false;
	        try {
	        	LogUtils.print(" setSmscAddress");
	        	ret = odmSzControlManager.setSmscAddress(smscAddress); 
	        	LogUtils.print(" setSmscAddress  smscAddress="+smscAddress +" ret="+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public String getIccid(String token) {
			long identity = Binder.clearCallingIdentity();
			String ret = "";
	        try {
	        	LogUtils.print(" getIccid");
	        	ret = odmSzControlManager.getIccid(); 
	        	LogUtils.print(" getIccid:"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public int getBatteryLevel(String token){
			long identity = Binder.clearCallingIdentity();
			int ret = -1;
	        try {
	        	LogUtils.print(" getBatteryLevel");
	        	ret = odmSzControlManager.getBatteryLevel(); 
	        	LogUtils.print(" getBatteryLevel:"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public String getCpuTemperature(String token){
			long identity = Binder.clearCallingIdentity();
			String ret = "";
	        try {
	        	LogUtils.print(" getCpuTemperature");
	        	ret = odmSzControlManager.getCpuTemperature(); 
	        	LogUtils.print(" getCpuTemperature:"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public int getNetWorkState(String token) throws RemoteException {
			long identity = Binder.clearCallingIdentity();
			int ret = -1;
	        try {
	        	LogUtils.print(" getNetWorkState");
	        	ret = odmSzControlManager.getNetWorkState(); 
	        	LogUtils.print(" getNetWorkState:"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public boolean isIms(String token) throws RemoteException {
			long identity = Binder.clearCallingIdentity();
			boolean ret = false;
	        try {
	        	LogUtils.print(" isIms");
	        	ret = odmSzControlManager.isImsReg(); 
	        	LogUtils.print(" isImsReg:"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public boolean setEnhanced4gLteModeSetting(boolean enable)
				throws RemoteException {
			long identity = Binder.clearCallingIdentity();
			boolean ret = false;
	        try {
	        	LogUtils.print(" setEnhanced4gLteModeSetting enable:"+enable);
	        	ret = odmSzControlManager.setEnhanced4gLteModeSetting(enable); 
	        	LogUtils.print(" setEnhanced4gLteModeSetting:"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public boolean isAdvancedCallingSettingEnabled() throws RemoteException {
			long identity = Binder.clearCallingIdentity();
			boolean ret = false;
	        try {
	        	LogUtils.print(" isAdvancedCallingSettingEnabled");
	        	ret = odmSzControlManager.isAdvancedCallingSettingEnabled(); 
	        	LogUtils.print(" isAdvancedCallingSettingEnabled:"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public boolean setAutoSelectNetwork() throws RemoteException {
			long identity = Binder.clearCallingIdentity();
			boolean ret = false;
	        try {
	        	LogUtils.print(" setAutoSelectNetwork");
	        	ret = odmSzControlManager.setAutoSelectNetwork(); 
	        	LogUtils.print(" setAutoSelectNetwork:"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

		@Override
		public boolean isAutoSelectNetwork() throws RemoteException {
			long identity = Binder.clearCallingIdentity();
			boolean ret = false;
	        try {
	        	LogUtils.print(" isAutoSelectNetwork");
	        	ret = odmSzControlManager.isAutoSelectNetwork(); 
	        	LogUtils.print(" isAutoSelectNetwork:"+ret);
	        }catch (Exception e){
	        	e.printStackTrace();
	        }finally {
	          	Binder.restoreCallingIdentity(identity);
	        }
	        return ret;
		}

	 

		
        
    };
}
