package com.odmsz.control;



import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import android.annotation.TargetApi;
import android.app.ActivityThread;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SqliteWrapper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.provider.Settings;
import android.provider.Telephony.Mms;
import android.provider.Telephony.Sms;
import android.service.carrier.CarrierMessagingService;
import android.telecom.Call;
import android.telecom.Phone;
import android.telecom.TelecomManager;
import android.telephony.CellInfo;
import android.telephony.CellInfoCdma;
import android.telephony.CellInfoGsm;
import android.telephony.CellInfoLte;
import android.telephony.CellInfoNr;
import android.telephony.CellInfoTdscdma;
import android.telephony.CellInfoWcdma;
import android.telephony.CellSignalStrengthCdma;
import android.telephony.CellSignalStrengthGsm;
import android.telephony.CellSignalStrengthLte;
import android.telephony.CellSignalStrengthNr;
import android.telephony.CellSignalStrengthWcdma;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.telephony.TelephonyProtoEnums;
import android.telephony.data.ApnSetting;
import android.telephony.ims.ImsMmTelManager;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.mms.MmsManager;
import androidx.appcompat.mms.pdu.CharacterSets;
import androidx.appcompat.mms.pdu.EncodedStringValue;
import androidx.appcompat.mms.pdu.GenericPdu;
import androidx.appcompat.mms.pdu.MmsFileProvider;
import androidx.appcompat.mms.pdu.PduBody;
import androidx.appcompat.mms.pdu.PduComposer;
import androidx.appcompat.mms.pdu.PduPart;
import androidx.appcompat.mms.pdu.SendReq;


import com.android.internal.telephony.IMms;
import com.android.internal.telephony.PhoneFactory;
import com.android.internal.telephony.PhoneSubInfoController;
import com.google.android.mms.pdu.PduPersister;
import com.odmsz.receiver.MmsSmsDatabaseChangeObserver;
import com.odmsz.receiver.OdmSzControlReceiver;
import com.odmsz.util.AdbCommand;
import com.odmsz.util.LogUtils;

/***
 * Telephony 接口类
 * @author xiaot
 *
 */
@TargetApi(Build.VERSION_CODES.L) public class OdmSzControlTelephony  {
	
    
    private static Context mContext;
    private  Call telecomCall;
    private  static String lastSms = "";
    private  static String lastMms = "";
    private  static long lastSmsBroadCastTime = 0;
    private  static long lastMmsBroadCastTime = 0;
	public static final int NETWORK_SELECTION_MODE_UNKNOWN = 0;
	public static final int NETWORK_SELECTION_MODE_AUTO = 1;//自动
	public static final int NETWORK_SELECTION_MODE_MANUAL = 2;//手动
	public OdmSzControlTelephony(Context context)
	{
        mContext = context;

    }
	

	
   /***
    *拨打电话
    * @param number
    */
   public static void call(String number) {
       //Intent.ACTION_CALL是直接拨打
       //Intent.ACTION_DIAL是调起拨号界面
	   LogUtils.print("callNumber:"+number);
       Intent intent = new Intent(Intent.ACTION_CALL);
       intent.setData(Uri.parse("tel:" + number.trim()));
       intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
       mContext.startActivity(intent);
   }
   
   
   /**
    * 接听电话
    */
   @SuppressWarnings("deprecation")
   public static boolean acceptRingingCall() {
	   boolean ret = false;
	   final TelecomManager telecomManager = TelecomManager.from(mContext);
	   if(telecomManager!=null){
		   int callState = getCallState();
		   LogUtils.print("callState:"+callState);
		   for(int i =0;i<6;i++){
			   if(callState==0){
					try {
						Thread.sleep(2000);
						callState = getCallState();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			   }else{
				   break;
			   }
			   
		   }
		   
		   telecomManager.acceptRingingCall(); 
		   LogUtils.print("telecomManager.acceptRingingCall");
		   callState = getCallState();
		   
		   LogUtils.print("callState:"+callState);
		   if(callState !=0 ){
			   ret = true; 
		   }
		 
	   }
	   return ret;
   }

	
	/**
	 * 挂断电话
	 */
	@SuppressWarnings("deprecation")
	public static boolean endCall() {
	   boolean ret = false;
	   final TelecomManager telecomManager = TelecomManager.from(mContext);
	   if(telecomManager!=null){
		   ret = telecomManager.endCall();
		   LogUtils.print("telecomManager.endCall"+ret);
		   int callState = getCallState();
		   LogUtils.print("callState:"+callState);
		   if(callState==0){
			   ret = true;
			   LogUtils.print("endCall ret:"+ret);
		   }
	   }
	   return ret;
	}


	   
	/**
	 * 发送短信
	 * 
	 * @param destinationAddress
	 * @param acAddress
	 * @param message
	 */
    public static void sendTextMessage(String destinationAddress,String scAddress, String message) {
        // 获取短信管理器
    	SmsManager smsManager = SmsManager.getDefault();

    	Intent sentIntent = new Intent(OdmSzControlReceiver.ACTION_SEND_SMS);
	    PendingIntent sentPI = PendingIntent.getBroadcast(mContext, 0, sentIntent, 0);
	    Intent deliveryIntent = new Intent(OdmSzControlReceiver.ACTION_DELIVERY_SMS);
	    PendingIntent deliverPI = PendingIntent.getBroadcast(mContext, 0, deliveryIntent, 0);
//	     如果短信内容超过70个字符 将这条短信拆成多条短信发送出去  
        if (message.length() > 70) {
        	List<String> divideContents = smsManager.divideMessage(message);
        	for (String text : divideContents) {
                smsManager.sendTextMessage(destinationAddress, scAddress, text, sentPI,
//                		null);
                        deliverPI);
            }
        } else {
        	smsManager.sendTextMessage(destinationAddress, scAddress, message, sentPI, deliverPI);
        }
    }
    
    /**
	 * 读取短信
	 * read  0 未读，1已读
	 * type ALL=0;INBOX=1;SENT=2;DRAFT=3;OUTBOX=4;FAILED=5;QUEUED=6;
	 */
    public static boolean readSms(long id,boolean update,int read) {
//    	Cursor query (Uri uri, String[] projection,String selection,String[] selectionArgs, StringsortOrder)
//    	int read = 0; //0-未读，1-已读
    	boolean ret = false;
    	long date = 0;
    	String address = "";
    	String body = "";
    	String serviceCenter = "";
    	String selection = "_id = "+ id;
    	
//  	    		"' and type = '" + 1 
//  	    		+"'"; 
    	Cursor smsCur =  mContext.getContentResolver().query(Uri.parse("content://sms/inbox"),
			       new String[]{"_id", "date", "address","body","service_center"},
			       selection, null,
			       // 根据 id 排序
			       "_id asc");
    	if(smsCur !=null && smsCur.getCount()>0){
    		ret = smsCur.moveToLast();
    		LogUtils.print("smsCur.moveToLast="+ret+" smsCur.getCount()="+smsCur.getCount());
    		if(ret){
    			 long pduId = smsCur.getLong(smsCur.getColumnIndex("_id"));
    			 date = smsCur.getLong(smsCur.getColumnIndex("date"));
    			 address =  smsCur.getString(smsCur.getColumnIndex("address"));
    			 body =  smsCur.getString(smsCur.getColumnIndex("body"));
    			 serviceCenter = smsCur.getString(smsCur.getColumnIndex("service_center"));
    			 LogUtils.print("address:"+address
    					 +"\npduId:"+pduId
    					 +"\nbody:"+body
    					 +"\nserviceCenter:"+serviceCenter);
    			 smsCur.close();
    			 
    			 //发送广播给上层APP
		    	final Intent smsIntent = new Intent();
		    	smsIntent.putExtra("date", date);
		    	smsIntent.putExtra("phone",address);
		    	smsIntent.putExtra("content",body);
		    	smsIntent.putExtra("centerAddress",serviceCenter);
		    	smsIntent.setAction(OdmSzControlReceiver.ODMSZ_SMS_RECEIVED);
		    	String smsStr = ""+pduId+body.length()+date+address;
		    	long currentTime = System.currentTimeMillis();
		    	long temp = currentTime-lastSmsBroadCastTime;
		    	LogUtils.print("temp:"+temp);
		    	final String smsBody = body;
		    	if(!smsStr.equals(lastSms)&&temp>=500){
		    		//校验短信内容
		    		new Thread(new Runnable() {
			            @Override
			            public void run() {
			            	AdbCommand adbCommand = new AdbCommand();
			            	String receiveSms = adbCommand.exec(" odmsz cat  /sdcard/receive_sms");
			            	LogUtils.print("read file receive_sms:"+receiveSms +" \nsmsBody:"+smsBody);
			            	if((!TextUtils.isEmpty(receiveSms))&& smsBody.equals(receiveSms.trim())){
			            		mContext.sendBroadcast(smsIntent);
			            	}
			            }
			        }).start();
				   
			    
			    	
			    	lastSms = smsStr;
			    	lastSmsBroadCastTime = currentTime;
			    	if(update){
	    				 updateSms(id,""+read);
	    			}
		    	}

		    	
    		}
    	}else{
    		LogUtils.print("smsCur is null or smsCur.getCount()=0");
			
    	}
		return ret;

    }
    
//    private static boolean isMmsDataAvailable(final int subId) {
//        return !phoneUtils.isAirplaneModeOn() && phoneUtils.isMobileDataEnabled();
//    }
//    public static byte[] sendMmsMessage(final Context context, final int subId,
//            final String furl, final Bundle extras,final String subject,final  String address) throws Exception {
//        int rawStatus = MessageData.RAW_TELEPHONY_STATUS_UNDEFINED;
//        if (!isMmsDataAvailable(subId)) {
//            LogUtil.w(TAG, "MmsUtils: failed to send message, no data available");
//            return new StatusPlusUri(MMS_REQUEST_MANUAL_RETRY,
//                    MessageData.RAW_TELEPHONY_STATUS_UNDEFINED,
//                    messageUri,
//                    SmsManager.MMS_ERROR_NO_DATA_NETWORK);
//        }
//        final PduPersister persister = PduPersister.getPduPersister(context);
//        try {
//            final SendReq sendReq = (SendReq) persister.load(messageUri);
//            if (sendReq == null) {
//                LogUtil.w(TAG, "MmsUtils: Sending MMS was deleted; uri = " + messageUri);
//                return new StatusPlusUri(MMS_REQUEST_NO_RETRY,
//                        MessageData.RAW_TELEPHONY_STATUS_UNDEFINED, messageUri);
//            }
//            if (LogUtil.isLoggable(TAG, LogUtil.DEBUG)) {
//                LogUtil.d(TAG, String.format("MmsUtils: Sending MMS, message uri: %s", messageUri));
//            }
    public static byte[] sendMmsMessage(
            final String furl, final String  type,final String subject,final  String address) throws Exception {

    	final SendReq sendReq = new SendReq();
    	if(subject!=null){
        	final EncodedStringValue[] sub = EncodedStringValue.extract(subject);
        	if (sub != null && sub.length > 0) {
        		sendReq.setSubject(sub[0]);
        	}
    	}

    	final EncodedStringValue[] phoneNumbers = EncodedStringValue.extract(address);
    	if (phoneNumbers != null&& phoneNumbers.length>0) {
    		sendReq.addTo(phoneNumbers[0]);
    	}
    	final PduBody pduBody = new PduBody();
    	final PduPart part = new PduPart();
    	part.setName("sample".getBytes());
    	part.setContentType(type.getBytes());
//    	String furl = "file:///sdcard//1.jpg";
    	Uri messageUri = Uri.parse(furl);
    	final PduPart partPdu = new PduPart();
    	partPdu.setCharset(CharacterSets.UTF_8);//UTF_16
    	partPdu.setName(part.getName());
    	partPdu.setContentType(part.getContentType());
    	partPdu.setDataUri(Uri.parse(furl));
    	pduBody.addPart(partPdu);
    	sendReq.setBody(pduBody);
    	final PduComposer composer = new PduComposer(mContext, sendReq);
    	final byte[] bytesToSend = composer.make();
    	LogUtils.print("bytesToSend :"+bytesToSend);
//            extras.putInt("sub_id", subId);
//        sendMms(context, subId, messageUri, sendReq, extras);
//            return STATUS_PENDING;
    	return bytesToSend;
    }
    
    
    public static void sendMms(final Context context, final int subId, final Uri messageUri,
            final SendReq sendReq, final Bundle sentIntentExras) throws Exception {
        	sendMms(context,
                subId,
                messageUri,
                null /* locationUrl */,
                sendReq,
                true /* responseImportant */,
                sentIntentExras);
    }
    
    public static void sendMms(final Context context, final int subId, final Uri messageUri,
            final String locationUrl, final GenericPdu pdu, final boolean responseImportant,
            final Bundle sentIntentExtras) throws Exception{
        // Write PDU to temporary file to send to platform
        final Uri contentUri =writePduToTempFile(context, pdu, subId);

        // Construct PendingIntent that will notify us when message sending is complete
        final Intent sentIntent = new Intent(OdmSzControlReceiver.ODMSZ_MMS_SENT_ACTION,
                messageUri,
                context,
                OdmSzControlReceiver.class);
        sentIntent.putExtra("content_uri", contentUri);
        sentIntent.putExtra("response_important", responseImportant);
        if (sentIntentExtras != null) {
            sentIntent.putExtras(sentIntentExtras);
        }
        final PendingIntent sentPendingIntent = PendingIntent.getBroadcast(
                context,
                0 /*request code*/,
                sentIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);

        // Send the message
        MmsManager.sendMultimediaMessage(subId, context, contentUri, locationUrl,
                sentPendingIntent);
    }
    
    private static Uri writePduToTempFile(final Context context, final GenericPdu pdu, int subId) throws Exception {
    	MmsFileProvider.mContext = context;
    	final Uri contentUri = MmsFileProvider.buildRawMmsUri();
        final File tempFile = MmsFileProvider.getFile(contentUri);
        FileOutputStream writer = null;
        try {
            // Ensure rawmms directory exists
            tempFile.getParentFile().mkdirs();
            writer = new FileOutputStream(tempFile);
            final byte[] pduBytes = new PduComposer(context, pdu).make();
            if (pduBytes == null) {
                throw new Exception("Failed to compose PDU");
            }
//            if (pduBytes.length > MmsConfig.get(subId).getMaxMessageSize()) {
//                throw new  Exception(
//                        "MmsUtils.MMS_REQUEST_NO_RETRY," +
//                        " MessageData.RAW_TELEPHONY_STATUS_MESSAGE_TOO_BIG");
//            }
            writer.write(pduBytes);
        } catch (final IOException e) {
            if (tempFile != null) {
                tempFile.delete();
            }
        } catch (final OutOfMemoryError e) {
            if (tempFile != null) {
                tempFile.delete();
            }
            LogUtils.print("Out of memory in composing PDU", e);
            throw new Exception("MmsUtils.MMS_REQUEST_MANUAL_RETRY," +
            		"MessageData.RAW_TELEPHONY_STATUS_MESSAGE_TOO_BIG");
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (final IOException e) {
                    // no action we can take here
                }
            }
        }
        return contentUri;
    }



    


    
    
    public static String getCarrierMessagingServicePackageIfExists() {
    	Intent intent = new Intent(CarrierMessagingService.SERVICE_INTERFACE);
    	TelephonyManager telephonyManager = TelephonyManager.from(mContext);
    	List<String> carrierPackages = telephonyManager.getCarrierPackageNamesForIntent(intent);
    	if (carrierPackages == null || carrierPackages.size() != 1) {
    		return null;
    	} else {
    		return carrierPackages.get(0);
    	}
    }

    
    
    public static boolean fileIsExists(String strFile) {
        try {
            File f=new File(strFile);
            if(f.exists()) {
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
        	LogUtils.e("读取文件异常"+e.getMessage());
            return false;
        }
    }
    
    
    /**
	 * 读取彩信
	 * read  0 未读，1已读
	 * msg_box 彩信属于哪个信箱，all为0，inbox为1，sent为2，draft为3，outbox为4，failed为5
	 */
    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static boolean readMms(long id,boolean update,int read) {
//    	Cursor query (Uri uri, String[] projection,String selection,String[] selectionArgs, StringsortOrder)
//    	int read = 0; //0-未读，1-已读
    	boolean ret = false;
    	long date = 0;
    	String address = "";
    	String sub = "";
    	String imageName = "";
    	String selection = "_id = " + id +"";
//  	    		"' and msg_box = '" + 1 
//  	    		+"'"; 
    	//查彩信id、日期（秒）、主题
    	LogUtils.print("readMms selection: " + selection);
    	Cursor mmsCur =  mContext.getContentResolver().query(Uri.parse("content://mms/inbox"),
			       new String[]{"_id", "date", "sub"},
			       selection, null,
			       // 根据 id 排序
			       "_id asc");
    	
    	if(mmsCur !=null && mmsCur.getCount()>0){
    		ret = mmsCur.moveToLast();
    		LogUtils.print("mmsCur.moveToLast="+ret+" mmsCur.getCount()"+mmsCur.getCount());
    		if(ret){
    			long pduId = mmsCur.getLong(mmsCur.getColumnIndex("_id"));
				date = mmsCur.getLong(mmsCur.getColumnIndex("date"));
				String dateStr = date+"000";
				byte[] body = getMmsImage(id);
				sub = getText(id);
				imageName = getMmsImageName(id);
				address = getMmsAddress(id);
				String mmsData = "\n pduId:" + pduId
						 		+ "\n sub:" + sub
						 		+"\n imageName:" +imageName
						 		+ "\n body:" + body
						 		+ "\n date:" + Long.valueOf(dateStr)
						 		+ "\n address:" + address;
				LogUtils.print("mmsData: " + mmsData);
				
				mmsCur.close();
    			 //发送广播给上层APP
		    	Intent mmsIntent = new Intent();
		    	mmsIntent.putExtra("date", Long.valueOf(dateStr));
		    	mmsIntent.putExtra("phone",address);
		    	mmsIntent.putExtra("sub",sub);
		    	mmsIntent.putExtra("image",body);
		    	mmsIntent.putExtra("imageName", imageName);
		    	mmsIntent.setAction(OdmSzControlReceiver.ODMSZ_MMS_RECEIVED);
		        if(body!=null){
	    			String mmsStr = ""+pduId+sub+body.length+dateStr+address;
	    			long currentTime = System.currentTimeMillis();
			    	long temp = currentTime-lastMmsBroadCastTime;
			    	LogUtils.print("temp: " + temp);
			    	if(!mmsStr.equals(lastMms)&&temp>500){
				    	mContext.sendBroadcast(mmsIntent);
				    	lastMms = mmsStr;
				    	lastMmsBroadCastTime=currentTime;
		    			 if(update){
		    				 updateMms(id ,""+read);
		    			 }
			    	}
		        }
    		}
    		
    	}else{
    		LogUtils.print("mmsCur is null");
			
    	}
		return ret;

    }
    
    public static int updateAllSmsMmsRead(){
        LogUtils.print("enter into updateAllSmsMmsRead");
		ContentValues values = new ContentValues();
		values.put("read", "1");
		values.put("seen", "1");
		int updateRet = -1;
		updateRet = mContext.getContentResolver().update(Uri.parse("content://sms/inbox"), values, null, null);
		updateRet = updateRet+mContext.getContentResolver().update(Uri.parse("content://mms/inbox"), values, null, null);
		LogUtils.print("updateAllSmsMmsRead updateRet="+updateRet);
        return updateRet; 
    }

    public static int updateSmsRead(String id){
        LogUtils.print("enter into updateSmsRead");
		ContentValues values = new ContentValues();
		values.put("read", "1");
		values.put("seen", "1");
		int updateRet = -1;
	    updateRet = mContext.getContentResolver().update(Uri.parse("content://sms/inbox"), values, "_id=?", new String[]{id});		LogUtils.print("updateSmsRead updateRet="+updateRet);
        return updateRet; 
    }
    

    public static int updateMmsRead(String id){
        LogUtils.print("enter into updateMmsRead");
		ContentValues values = new ContentValues();
		values.put("read", "1");
		values.put("seen", "1");
		int updateRet = -1;
        updateRet = mContext.getContentResolver().update(Uri.parse("content://mms/inbox"), values, "_id=?", new String[]{id});
		LogUtils.print("updateMmsRead updateRet="+updateRet);
        return updateRet; 
    }
    public static void updateMms(long id ,String read){
    	LogUtils.print("updateMms id="+id+"read="+read);
    	Intent intent = new Intent("android.provider.Telephony.ODMSZ_MMS_SMS_UPDATE");
    	intent.putExtra("type", "mms");
    	intent.putExtra("id", ""+id);
    	intent.putExtra("read", read);
    	intent.setComponent(new ComponentName("com.android.messaging", "com.android.messaging.receiver.OdmSzReceiver"));
        intent.setClassName("com.android.messaging", "com.android.messaging.receiver.OdmSzReceiver");
    	mContext.sendBroadcast(intent);
    }
    
    public static void updateSms(long id ,String read){
    	LogUtils.print("updateSms id="+id+"read="+read);
    	Intent intent = new Intent("android.provider.Telephony.ODMSZ_MMS_SMS_UPDATE");
    	intent.putExtra("type", "sms");
    	intent.putExtra("id", ""+id);
    	intent.putExtra("read", read);
    	intent.setComponent(new ComponentName("com.android.messaging", "com.android.messaging.receiver.OdmSzReceiver"));
        intent.setClassName("com.android.messaging", "com.android.messaging.receiver.OdmSzReceiver");
    	mContext.sendBroadcast(intent);
        
    }

    /**
     * 查彩信号码
     *
     * @param pduId 彩信 id
     * @return 彩信发送对象的号码
     * 电话号码的类型，必须为PduHeaders.BCC-129，PduHeaders.CC-130，
     * PduHeaders.FROM-137，PduHeaders.TO-151之一
     */
    private static String getMmsAddress(long pduId) {
       String address = "";
       String numberUri = MessageFormat.format("content://mms/{0}/addr", pduId);
       String selection = "type = " + 137 +"";
       Cursor addrCur = mContext.getContentResolver().query(Uri.parse(numberUri),
             new String[]{"address"}, selection, null, null);

       if (addrCur != null) {
    	   addrCur.moveToLast();
          address = addrCur.getString(addrCur.getColumnIndex("address"));
          addrCur.close();
       } else {
     	 LogUtils.print("onChange: addCur is null");
       }
       return address;
    }

    
    
    /**
     *  查彩信附件内容
     *
     * @param pduId 彩信 id
     * @return  查彩信附件内容
     */
    private static Object getMmsBody(long pduId) {
       Object body = null;
       // 查 part 表
       Cursor cursor = mContext.getContentResolver().query(Uri.parse("content://mms/part"),
             null, "mid=" + pduId, null, null);
       if (cursor != null && cursor.getCount() > 0) {
          cursor.moveToLast();
          // part表 ct 字段 标识此part内容类型，彩信始末：application/smil；
          // 文本附件：text/plain；图像附件：jpg：image/jpeg，gif：image/gif..；音频附件：audio/amr
          String type = cursor.getString(cursor.getColumnIndex("ct"));
          LogUtils.print("type=" + type);
          String text = "text/plain";
          if (text.equals(type)) {
             String data = cursor.getString(cursor.getColumnIndex("_data"));
             LogUtils.print("_data=" + data);
             if (data != null) {
                int id = cursor.getInt(cursor.getColumnIndex("_id"));
                LogUtils.print("_id=" + id);
                body = getMmsText(id);
             }
          } else {
             boolean isImage = "image/jpeg".equals(type) || "image/bmp".equals(type)
                   || "image/gif".equals(type) || "image/png".equals(type)
                   || "image/jpg".equals(type);
             if (isImage) {
                String data = cursor.getString(cursor.getColumnIndex("_data"));
                 LogUtils.print("_data=" + data);
                if (data != null) {
                   int id = cursor.getInt(cursor.getColumnIndex("_id"));
                    LogUtils.print(" _id=" + id);
                   body = getMmsImage(id);
                }
             } else {
                String audio = "audio/amr";
                if (audio.equals(type)) {
                   String audioPath = cursor.getString(cursor.getColumnIndex("fn"));
                    LogUtils.print("audioPath=" + audioPath);
                   if (!TextUtils.isEmpty(audioPath)) {
                      String audioDir = Environment.getExternalStorageDirectory() + "/Recordings/";
                      body = audioDir + audioPath;
                   }
                } else {
                   body = cursor.getString(cursor.getColumnIndex("text"));
                }
             }
          }
          cursor.close();
       }

       return body;
    }
    
    /**
     * 查彩信图片
     *
     * @param pduId 彩信 id
     * @return 彩信图片
     */
    private static byte[] getMmsImage(long pduId) {
    	byte[] body = null;
       // 查 part 表
       Cursor cursor = mContext.getContentResolver().query(Uri.parse("content://mms/part"),
             null, "mid=" + pduId+" and ct like 'image%'", null, null);
       if (cursor != null && cursor.getCount() > 0) {
    	  LogUtils.print("getMmsImage:"+cursor.getCount());
          cursor.moveToLast();
          String data = cursor.getString(cursor.getColumnIndex("_data"));
          LogUtils.print("_data=" + data);
          if (data != null) {
        	  int id = cursor.getInt(cursor.getColumnIndex("_id"));
        	  LogUtils.print(" _id=" + id);
        	  body = getMmsImage(id);
          }
          cursor.close();
       }

       return body;
    }
    
    /**
     * 查彩信图片名称
     *
     * @param pduId 彩信 id
     * @return 彩信图片
     */
    private static String getMmsImageName(long pduId) {
       String name = "";
       // 查 part 表
       Cursor cursor = mContext.getContentResolver().query(Uri.parse("content://mms/part"),
             null, "mid=" + pduId+" and ct like 'image%'", null, null);
       if (cursor != null && cursor.getCount() > 0) {
    	  LogUtils.print("getMmsImageName:"+cursor.getCount());
          cursor.moveToLast();
          String data = cursor.getString(cursor.getColumnIndex("_data"));
          LogUtils.print("_data=" + data);
          if (data != null) {
        	  int id = cursor.getInt(cursor.getColumnIndex("_id"));
        	  name = cursor.getString(cursor.getColumnIndex("name"));
        	  LogUtils.print(" _id=" + id+" name="+name);
          }
          cursor.close();
       }

       return name;
    }
    
    
    /**
     * 查text
     *
     * @param pduId 彩信 id
     */
    private static String getText(long pduId) {
    	String text = "";
       // 查 part 表
       Cursor cursor = mContext.getContentResolver().query(Uri.parse("content://mms/part"),
             null, "mid=" + pduId+" and ct like 'text%'", null, null);
       
       if (cursor != null && cursor.getCount() > 0) {
    	  LogUtils.print("getMmsImageText:"+cursor.getCount());
          cursor.moveToLast();
          text = cursor.getString(cursor.getColumnIndex("text"));
          LogUtils.print("text=" + text);
          cursor.close();
       }

       return text;
    }

    /**
     * 查图片类型的彩信
     *
     * @param id 彩信id
     * @return 彩信的图片数组
     */
    private static byte[] getMmsImage(int id) {
       Uri uri = Uri.parse("content://mms/part/" + id);
       InputStream inputStream = null;
       try {
          inputStream = mContext.getContentResolver().openInputStream(uri);
          Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
          ByteArrayOutputStream baos = new ByteArrayOutputStream();
          bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
          return baos.toByteArray();
       } catch (Exception e) {
          e.printStackTrace();
       } finally {
          if (inputStream != null) {
             try {
                inputStream.close();
             } catch (IOException e) {
                e.printStackTrace();
             }
          }
       }
       return null;
    }

    /**
     * 查文本类型的彩信
     *
     * @param id 彩信 id
     * @return 彩信的文本内容
     */
    @TargetApi(Build.VERSION_CODES.KITKAT) 
    private static String getMmsText(int id) {

       StringBuilder stringBuilder = new StringBuilder();
       InputStream inputStream = null;
       InputStreamReader inputStreamReader = null;
       BufferedReader reader = null;
       try {
          inputStream = mContext.getContentResolver().openInputStream(Uri.parse("content://mms/part/" + id));
          if (inputStream != null) {
             inputStreamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
             reader = new BufferedReader(inputStreamReader);
             String s = reader.readLine();
             while (s != null) {
                stringBuilder.append(s);
                s = reader.readLine();
             }
             return stringBuilder.toString();
          }

       } catch (Exception e) {
          e.printStackTrace();
       } finally {
          if (inputStream != null) {
             try {
                inputStream.close();
             } catch (IOException e) {
                e.printStackTrace();
             }
          }
          if (inputStreamReader != null) {
             try {
                inputStreamReader.close();
             } catch (IOException e) {
                e.printStackTrace();
             }
          }
          if (reader != null) {
             try {
                reader.close();
             } catch (IOException e) {
                e.printStackTrace();
             }
          }
       }
       return stringBuilder.toString();
    }
    

    /**
     * 获取网络类型
     * @return
     *      
    int NO_PHONE = 0;//无卡
    int GSM_PHONE = 1;//G网
    int CDMA_PHONE = 2;//C网
    int SIP_PHONE  = 3;
    int THIRD_PARTY_PHONE = 4;
    int IMS_PHONE = 5;
    int CDMA_LTE_PHONE = 6;
     */
	public static int getPhoneType() {
		final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			return telephonyManager.getPhoneType();
		}
		
		return 0;
	}
    
	
	public static boolean imsReg() {
		final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			return telephonyManager.isImsRegistered();
		}
		
		return false;
	}
	
	
    /**
     * 查询是否为飞行模式
     * @param context
     * @return
     */
	public static boolean getAirPlaneModeStatus(){
    	LogUtils.print( "enter into getAirPlaneModeStatus start");
    	String airPlaneModeStatus="";
    	boolean ret=false;
    	if(mContext!=null){
        	final ContentResolver resolver = mContext.getContentResolver();
        	if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.JELLY_BEAN) {
        		airPlaneModeStatus= Settings.System.getString(resolver,
            			Settings.System.AIRPLANE_MODE_ON);
        	}else{
        		airPlaneModeStatus= Settings.System.getString(resolver,
        				Settings.Global.AIRPLANE_MODE_ON);
        	}
        	
        	if("1".equals(airPlaneModeStatus)){
        		ret=true;
        	}
        	LogUtils.print( "getAirPlaneModeStatus() end airPlaneModeStatus="+airPlaneModeStatus);
    	}
    	return ret;
    }
	
	/**
	 * 设置飞行模式
	 * @param context
	 * @param enable
	 */
	public static void setAirPlaneMode(boolean enable) {
	    if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.JELLY_BEAN) {
	        Settings.System.putInt(mContext.getContentResolver(), Settings.System.AIRPLANE_MODE_ON, enable ? 1 : 0);
	    } else {
	        Settings.Global.putInt(mContext.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, enable ? 1 : 0);
	    }
	    Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
	    intent.putExtra("state", enable);
	    mContext.sendBroadcast(intent);
	    TelephonyManager.from(mContext).setRadio(enable);
	}

	public static String getDeviceModel(){
		LogUtils.print("DeviceModel="+Build.MODEL);
		return (Build.MODEL).toUpperCase();
	}
	

	public static String getDeviceBrand(){
		LogUtils.print("DeviceBrand="+Build.BRAND);
		return (Build.BRAND).toUpperCase();
	}
   

	public static boolean isAndroid11(){
		String version=android.os.Build.VERSION.RELEASE;
		LogUtils.print("version:"+version);
		return version!=null&&version.contains("11.");
	}




	public static CallForwardingInfo getCallForwarding(int callForwardingReason) {
		final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			android.telephony.CallForwardingInfo info = telephonyManager.getCallForwarding(callForwardingReason);
			LogUtils.print("getCallForwarding:"+info);
			if(info!=null){
				LogUtils.print("getCallForwarding:"+info.toString());
				return new CallForwardingInfo(info.getStatus(),info.getReason(),
						info.getNumber(),info.getTimeoutSeconds());
			}
		}
		return null;
	}




	public static boolean setCallForwarding(CallForwardingInfo info) {
		android.telephony.CallForwardingInfo callForwardingInfo = new android.telephony.CallForwardingInfo(info.getStatus(),
										info.getReason(),info.getNumber(),info.getTimeoutSeconds());
		boolean ret = false;
		final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			ret=telephonyManager.setCallForwarding(callForwardingInfo);
			LogUtils.print("setCallForwarding ret="+ret);
		}
		return ret;
	}



	/***
	 * *获取呼叫等待状态
	 * @return
	 *int CALL_WAITING_STATUS_ACTIVE = 1;
     *int CALL_WAITING_STATUS_INACTIVE = 2;
     *int CALL_WAITING_STATUS_UNKNOWN_ERROR = 3;
     *int CALL_WAITING_STATUS_NOT_SUPPORTED = 4;
	 */
	public static int getCallWaitingStatus() {
		int ret=0;
		final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			ret=telephonyManager.getCallWaitingStatus();
		}
		return ret;
	}


	
	/***
	 * 设置呼叫等待状态
	 * @param isEnable
	 * @return
	 */

	public static boolean setCallWaitingStatus(boolean isEnable) {
		boolean ret=false;
		final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			ret=telephonyManager.setCallWaitingStatus(isEnable);
		}
		return ret;
	}




	public static boolean isRinging() {
		boolean ret=false;
		final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			ret=telephonyManager.isRinging();
		}
		return ret;
	}



	
	public static boolean isInCall() {
		boolean ret=false;
		final TelecomManager telecomManager = TelecomManager.from(mContext);
		if(telecomManager!=null){
			ret=telecomManager.isInCall();
		}
		return ret;
	}




	public static boolean silenceRinger() {
		boolean ret=true;
		final TelecomManager telecomManager = TelecomManager.from(mContext);
		if(telecomManager!=null){
			telecomManager.silenceRinger();
		}
		return ret;
	}

	  /**
     * 获取当前卡槽网络模式
     * */
    public static int getPreferredNetwork(int slot){
    	int ret = 0;
    	slot=0;
    	LogUtils.print("enter into getPreferredNetwork slot="+slot);
    	List<SubscriptionInfo> subInfos = SubscriptionManager.from(mContext).getActiveSubscriptionInfoList();
    	LogUtils.print( "subInfos size:"+subInfos.size());
    	if(subInfos.size() == 0){
    		LogUtils.print( "SubscriptionInfo sir == null");
        	return -2;
    	}

    	for(SubscriptionInfo subInfo : subInfos){
    		final int subId = subInfo.getSubscriptionId();
    		LogUtils.print( "subId:"+subId);
      	    ret = TelephonyManager.from(mContext).getPreferredNetworkType(subId);
    	}
    	LogUtils.print( "enter into getPreferredNetwork(),networktype ="+ret);
        	
    	return ret;
    }
    
    /**
     * 设置当前卡槽网络模式
     * 
     * */
    public static boolean setPreferredNetwork(int slot, int networktype)
    {
    	boolean ret = true;
    	slot=0;
    	LogUtils.print("enter into setPreferredNetwork slot="+slot + "networktype = "+networktype);
    	if(networktype>=0){
    		List<SubscriptionInfo> subInfos = SubscriptionManager.from(mContext).getActiveSubscriptionInfoList();
        	LogUtils.print( "subInfos size:"+subInfos.size());
        	if(subInfos.size() == 0){
        		LogUtils.print( "SubscriptionInfo sir == null");
            	return false;
        	}
        	for(SubscriptionInfo subInfo : subInfos){
        		final int subId = subInfo.getSubscriptionId();
        		LogUtils.print( "subId:"+subId);
        		final int phoneId = SubscriptionManager.getPhoneId(subId);
        		LogUtils.print( "enter into setPreferredNetwork(),phoneId ="+phoneId);
        		if(phoneId < 0){
        			 return false;
        		}
        		TelephonyManager.from(mContext).setPreferredNetworkType(subId, networktype);
        	}
    	}
    	return ret;
    }
    
    
    
    /**
     * 获取漫游状态
     */
    
    public static boolean isDataRoamingEnabled(){
    	boolean ret=false;
    	final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			ret = telephonyManager.isDataRoamingEnabled();
			LogUtils.print("isDataRoamingEnabled:"+ret);
		}
		return ret;
    }
    
    public List<Call> getCalls(int slot){
    	com.android.internal.telephony.Phone phone = PhoneFactory.getDefaultPhone();//getPhone(slot);
    	com.android.internal.telephony.Call call = phone.getRingingCall();
    	
    	return null;
    }
    
    
    /**
     * 设置漫游状态
     */
    
    public static void setDataRoamingEnabled(boolean enable){
    	final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			telephonyManager.setDataRoamingEnabled(enable);
			LogUtils.print("setDataRoamingEnabled:"+enable);
		}
    }
    
    
    /**
     * 获取服务状态
     * @see #STATE_IN_SERVICE  0 
     * @see #STATE_OUT_OF_SERVICE 1
     * @see #STATE_EMERGENCY_ONLY  2 
     * @see #STATE_POWER_OFF  3
     * @return
     */
    public static int getServiceState(){
    	int ret = 1;
    	final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			ServiceState serviceState = telephonyManager.getServiceState();
			ret = serviceState.getState();
			LogUtils.print("getServiceState:"+ ret);
		}
		return ret;
    }
    

    /***
     *获取当前通话的状态
     *
     */
    public static int getCallStateForSlot(int slot){
    	int ret = 0;
    	slot=0;
    	final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			ret = telephonyManager.getCallStateForSlot(slot);
			LogUtils.print(slot+"|getCallStateForSlot :"+ret);
		}
		return ret;
    }
    
    /***
     *获取当前通话的状态
     *
     */
    public static int getCallState(){
    	int ret = 0;
    	final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			ret = telephonyManager.getCallState();
			LogUtils.print("getCallState :"+ret);
		}
		return ret;
    }
    
    
    
    /***
     *获取当前手机号码
     *
     */
    public static String getLine1Number(){
    	String ret = "";
    	final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			ret = telephonyManager.getLine1Number();
			LogUtils.print("getLine1Number:"+ret);
		}
		return ret;
    }
    
    /***
     *获取当前手机imsi
     *
     */
    public static String getSubscriberId(){
    	String ret = "";
    	final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			ret = telephonyManager.getSubscriberId();
			LogUtils.print("getSubscriberId:"+ret);
		}
		return ret;
    }
    
    /***
     *获取卡状态

     *
     * @see #SIM_STATE_UNKNOWN
     * @see #SIM_STATE_ABSENT
     * @see #SIM_STATE_PIN_REQUIRED
     * @see #SIM_STATE_PUK_REQUIRED
     * @see #SIM_STATE_NETWORK_LOCKED
     * @see #SIM_STATE_READY
     * @see #SIM_STATE_NOT_READY
     * @see #SIM_STATE_PERM_DISABLED
     * @see #SIM_STATE_CARD_IO_ERROR
     * @see #SIM_STATE_CARD_RESTRICTED
     *
     */
    public static int getSimState(){
    	int ret=TelephonyManager.SIM_STATE_UNKNOWN;
    	final TelephonyManager telephonyManager = TelephonyManager.from(mContext);
		if(telephonyManager!=null){
			ret = telephonyManager.getSimState();
			LogUtils.print("getSimState:"+ret);
		}
		return ret;
    }
    
    /**
     * 获取小区信息
     * @return
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2) public static List<CellIdentity> getCellInfo(){

        int dbm = -1;
        int ecio = -1;
        List<CellIdentity> cellInfos = new ArrayList<CellIdentity>();
        List<CellInfo> cellInfoList = TelephonyManager.from(mContext).getAllCellInfo();
		if (null != cellInfoList){
			LogUtils.print("cellInfoList size:"+cellInfoList.size());
			for (CellInfo cellInfo : cellInfoList){
				if (cellInfo instanceof CellInfoGsm){//移动联通2G
	                CellSignalStrengthGsm cellSignalStrengthGsm = ((CellInfoGsm)cellInfo).getCellSignalStrength();
	                final android.telephony.CellIdentityGsm identityGsm = (android.telephony.CellIdentityGsm) cellInfo.getCellIdentity();
	                dbm = cellSignalStrengthGsm.getDbm();
	                LogUtils.print(identityGsm.toString()+"| dbm="+dbm);
//	                CellIdentityGsm(int lac, int cid, int arfcn, int bsic,
//	                		String mccStr,String mncStr,  String alphal,  String alphas,
//	                        Collection<String> additionalPlmns,int dbm
	                CellIdentityGsm ciGsm = new CellIdentityGsm(identityGsm.getLac(),identityGsm.getCid(),identityGsm.getArfcn(),identityGsm.getBsic(),
	                		identityGsm.getMccString(),identityGsm.getMncString(),""+identityGsm.getOperatorAlphaLong(),""+identityGsm.getOperatorAlphaShort(),
	                		identityGsm.getAdditionalPlmns(),dbm);
	                cellInfos.add(ciGsm);
				}else if (cellInfo instanceof CellInfoCdma){//电信2G
					CellSignalStrengthCdma cellSignalStrengthCdma=  (CellSignalStrengthCdma) cellInfo.getCellSignalStrength();
					final android.telephony.CellIdentityCdma identityCdma = (android.telephony.CellIdentityCdma) cellInfo.getCellIdentity();
					dbm = cellSignalStrengthCdma.getDbm();
					ecio = cellSignalStrengthCdma.getEvdoEcio();
					LogUtils.print(identityCdma.toString()+"| dbm="+dbm+"| ecio="+ecio);
//					CellIdentityCdma(int nid, int sid, int bid, int lon, int lat,
//				             String alphal,  String alphas,int dbm,int ecio) 
					CellIdentityCdma ciCdma = new CellIdentityCdma(identityCdma.getNetworkId()
							,identityCdma.getSystemId(),identityCdma.getBasestationId(),
							identityCdma.getLongitude(),identityCdma.getLatitude(),
							""+identityCdma.getOperatorAlphaLong(),""+identityCdma.getOperatorAlphaShort(),dbm,ecio);
					cellInfos.add(ciCdma);
				}else if (cellInfo instanceof CellInfoTdscdma){//移动3G(目前基本废弃)
					LogUtils.e("CellInfoTdscdma not support");
	            }else if (cellInfo instanceof CellInfoWcdma){//联通3G
                    CellSignalStrengthWcdma cellSignalStrengthWcdma = ((CellInfoWcdma)cellInfo).getCellSignalStrength();
                    final android.telephony.CellIdentityWcdma identityWcdma = (android.telephony.CellIdentityWcdma) cellInfo.getCellIdentity();
                    dbm = cellSignalStrengthWcdma.getDbm();
                    LogUtils.print(identityWcdma.toString()+"| dbm="+dbm);
//                    public CellIdentityWcdma(int lac, int cid, int psc, int uarfcn,  String mccStr,
//                            String mncStr,  String alphal,  String alphas,
//                            Collection<String> additionalPlmns,
//                            boolean csgIndicator,String homeNodebName,int csgIdentity,int dbm){
                    CellIdentityWcdma ciWcdma =null;
                    if(identityWcdma.getClosedSubscriberGroupInfo()!=null){
                    	ciWcdma = new CellIdentityWcdma(identityWcdma.getLac(), identityWcdma.getCid(), identityWcdma.getPsc(),
                        		identityWcdma.getUarfcn(), identityWcdma.getMccString(), identityWcdma.getMncString(), 
                        		""+identityWcdma.getOperatorAlphaLong(),""+identityWcdma.getOperatorAlphaShort(),
                        		identityWcdma.getAdditionalPlmns(), identityWcdma.getClosedSubscriberGroupInfo().getCsgIndicator(),
                        		identityWcdma.getClosedSubscriberGroupInfo().getHomeNodebName(), identityWcdma.getClosedSubscriberGroupInfo().getCsgIdentity(), dbm);
                    }else{
                    	ciWcdma = new CellIdentityWcdma(identityWcdma.getLac(), identityWcdma.getCid(), identityWcdma.getPsc(),
                        		identityWcdma.getUarfcn(), identityWcdma.getMccString(), identityWcdma.getMncString(), 
                        		""+identityWcdma.getOperatorAlphaLong(),""+identityWcdma.getOperatorAlphaShort(),
                        		identityWcdma.getAdditionalPlmns(), false,
                        		"", 0, dbm);

                    }
                    
                    cellInfos.add(ciWcdma);
	            }else if (cellInfo instanceof CellInfoLte){//4G
	                CellSignalStrengthLte cellSignalStrengthLte = ((CellInfoLte)cellInfo).getCellSignalStrength();
	                final android.telephony.CellIdentityLte identityLte = (android.telephony.CellIdentityLte) cellInfo.getCellIdentity();
	                dbm = cellSignalStrengthLte.getDbm();
	                LogUtils.print(identityLte.toString()+"| dbm="+dbm);
//	                public CellIdentityLte(int ci, int pci, int tac, int earfcn,  int[] bands,
//	                        int bandwidth,  String mccStr,  String mncStr,
//	                         String alphal,  String alphas,
//	                         Collection<String> additionalPlmns,
//	                         boolean csgIndicator,String homeNodebName,int csgIdentity,int dbm){
	                CellIdentityLte ciLte =null;
	                if(identityLte.getClosedSubscriberGroupInfo()!=null){
	                	ciLte = new CellIdentityLte(identityLte.getCi(), identityLte.getPci(), identityLte.getTac(),identityLte.getEarfcn(),
		                		identityLte.getBands(), identityLte.getBandwidth(), identityLte.getMccString(),identityLte.getMncString(),
		                		""+identityLte.getOperatorAlphaLong(),""+identityLte.getOperatorAlphaShort(),
		                		identityLte.getAdditionalPlmns(), identityLte.getClosedSubscriberGroupInfo().getCsgIndicator(),
		                		identityLte.getClosedSubscriberGroupInfo().getHomeNodebName(), identityLte.getClosedSubscriberGroupInfo().getCsgIdentity(), dbm);
	                }else{
	                	ciLte = new CellIdentityLte(identityLte.getCi(), identityLte.getPci(), identityLte.getTac(),identityLte.getEarfcn(),
		                		identityLte.getBands(), identityLte.getBandwidth(), identityLte.getMccString(),identityLte.getMncString(),
		                		""+identityLte.getOperatorAlphaLong(),""+identityLte.getOperatorAlphaShort(),
		                		identityLte.getAdditionalPlmns(), false,
                        		"", 0, dbm);
	                }
	                cellInfos.add(ciLte);
	            
	            }else if (cellInfo instanceof CellInfoNr){//5G
	            	CellSignalStrengthNr cellSignalStrengthNr = (CellSignalStrengthNr) cellInfo.getCellSignalStrength();
	            	final android.telephony.CellIdentityNr identityNr = (android.telephony.CellIdentityNr) cellInfo.getCellIdentity();
	            	dbm = cellSignalStrengthNr.getDbm();
	            	LogUtils.print(identityNr.toString()+"| dbm="+dbm);
//	                public CellIdentityNr(int pci, int tac, int nrArfcn, int[] bands,
//	                          String mccStr, String mncStr, long nci,
//	                          String alphal, String alphas,
//	                          Collection<String> additionalPlmns,int dbm) {
	            	CellIdentityNr ciNr = new CellIdentityNr(identityNr.getPci(), identityNr.getTac(), identityNr.getNrarfcn(), identityNr.getBands(),
	            			identityNr.getMccString(), identityNr.getMncString(),identityNr.getNci(),
	            			""+identityNr.getOperatorAlphaLong(),""+identityNr.getOperatorAlphaShort(),
	            			identityNr.getAdditionalPlmns(), dbm);
	            	cellInfos.add(ciNr);
	            }
	        }
			LogUtils.print("cellInfos size:"+cellInfos.size());
			LogUtils.print("cellInfos size:"+cellInfos);
	    }
		
		
        return cellInfos;

    }



	public static String getServiceDomain() {
		return "CS/PS";
	}


	public static void callForward(final String forwardNumber) {
	    Intent dialIntent = new Intent(Intent.ACTION_CALL,
	            Uri.parse(String.format("tel:%s", Uri.encode(forwardNumber))));
	    dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	    mContext.startActivity(dialIntent);
	}
	public static void sendUssdRequest(final String number){
		 new Thread(new Runnable() {
	         @Override
	         public void run() {
	             TelephonyManager.UssdResponseCallback ussdCallback =
	                     new TelephonyManager.UssdResponseCallback() {
	                         @Override
	                         public void onReceiveUssdResponse(
	                                 final TelephonyManager telephonyManager,
	                                 String request, CharSequence response) {
	                             LogUtils.print("handleCallerIdUssdResponse  : " +
	                            		"\n request = "+request+
	                             		"\n response ="
	                                     + response.toString());
	                            Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
	                     	    intent.putExtra("request", request);
	                     	    intent.putExtra("response", response.toString());
	                     	    intent.putExtra("code", 0);
	                     	    intent.setAction(OdmSzControlReceiver.ODMSZ_USSD_SENT_ACTION);
	                     	    mContext.sendBroadcast(intent);
	                         }

	                         @Override
	                         public void onReceiveUssdResponseFailed(
	                                 final TelephonyManager telephonyManager,
	                                 String request, int failureCode) {
	                         	 LogUtils.print("handleCallerIdUssdResponse  : " +
	                         			"\n request = "+request+
	                         	 		"\n failureCode ="
	                                     + failureCode);
	                            Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
	                     	    intent.putExtra("request", request);
	                     	    intent.putExtra("response", "");
	                     	    intent.putExtra("code", failureCode);
	                     	    intent.setAction(OdmSzControlReceiver.ODMSZ_USSD_SENT_ACTION);
	                     	    mContext.sendBroadcast(intent);
	                         }
	                     };

	             TelephonyManager telephonyManager =
	                     (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
	             telephonyManager.sendUssdRequest(number, ussdCallback, null);
	             LogUtils.print("sendUssdRequest: " +number);
	         }
	     }).start();
	}
	

	public static String getSmscAddress(){
		SmsManager smsManager=SmsManager.getDefault();
		if(smsManager!=null){
			return smsManager.getSmscAddress();
		}
		return "";
	}
	
	public static boolean setSmscAddress(String smscAddress){
		boolean ret = false;
		SmsManager smsManager=SmsManager.getDefault();
		ret = smsManager.setSmscAddress(smscAddress);
		return ret;
	}
	
	public static String getIccid(){
//		TelephonyManager tm = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
//		String iccid = tm.getSimSerialNumber();
//		com.android.internal.telephony.Phone phone = PhoneFactory.getPhone(0);
//    	String iccid = phone.getFullIccSerialNumber();
		String iccid="";
		List<SubscriptionInfo> subInfos = SubscriptionManager.from(mContext).getActiveSubscriptionInfoList();
    	LogUtils.print( "subInfos size:"+subInfos.size());
    	if(subInfos.size() == 0){
    		LogUtils.print( "SubscriptionInfo sir == null");
        	return "";
    	}

    	for(SubscriptionInfo subInfo : subInfos){
    		iccid = subInfo.getIccId();
//      	    ret = TelephonyManager.from(mContext).getPreferredNetworkType(subId);
    	}
    	
		LogUtils.print("iccid: " +iccid);
		return iccid;
	}
	
	public static int getBatteryLevel(){
		BatteryManager manager = (BatteryManager)mContext.getSystemService(mContext.BATTERY_SERVICE);
		int currentLevel = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
		LogUtils.print("currentLevel: " +currentLevel);
		return currentLevel;
	}




	 /**
     * 获取当前的网络状态 ：-1,无卡；没有网络-0：5G网络5：4G网络-4：3G网络-3：2G网络-2,WIFI网络1
     */
    public static int getNetWorkState(Context context){
    	
    	int simState = getSimState();
    	
    	LogUtils.print("simState: " +simState);
    	if(simState != TelephonyManager.SIM_STATE_READY){
    		return -1;
    	}
        //结果返回值
        int netType = 0;
        //获取手机所有连接管理对象
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        //获取NetworkInfo对象
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();

        if (networkInfo == null) {
			LogUtils.print("getActiveNetworkInfo is null ");
			//如果没有默认的网络设置，getActiveNetworkInfo可以返回null。“当没有默认网络时，这可能返回null。”
			ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			networkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		}
		LogUtils.print("networkInfo: "+networkInfo);
		if(networkInfo != null){
			//否则 NetworkInfo对象不为空 则获取该networkInfo的类型
			int nType = networkInfo.getType();
			if (nType == ConnectivityManager.TYPE_WIFI) {
				//WIFI
				netType = 1;
			} else if (nType == ConnectivityManager.TYPE_MOBILE) {
				int nSubType = networkInfo.getSubtype();
				LogUtils.print("nSubType: " +nSubType);
				TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
				//3G   联通的3G为UMTS或HSDPA 电信的3G为EVDO
				if(nSubType == TelephonyManager.NETWORK_TYPE_NR
						&& !telephonyManager.isNetworkRoaming()){
					netType = 5;
				}else if (nSubType == TelephonyManager.NETWORK_TYPE_LTE
						&& !telephonyManager.isNetworkRoaming()) {
					netType = 4;
				}else if (nSubType == TelephonyManager.NETWORK_TYPE_UMTS
						|| nSubType == TelephonyManager.NETWORK_TYPE_HSDPA
						|| nSubType == TelephonyManager.NETWORK_TYPE_EVDO_0
						|| nSubType == TelephonyManager.NETWORK_TYPE_EVDO_A
						|| nSubType == TelephonyManager.NETWORK_TYPE_HSUPA
						|| nSubType == TelephonyManager.NETWORK_TYPE_HSPA
						|| nSubType == TelephonyManager.NETWORK_TYPE_EVDO_B
						|| nSubType == TelephonyManager.NETWORK_TYPE_EHRPD
						|| nSubType == TelephonyManager.NETWORK_TYPE_HSPAP
						&& !telephonyManager.isNetworkRoaming()) {
					netType = 3;
					//2G 移动和联通的2G为GPRS或EGDE，电信的2G为CDMA
				} else if (nSubType == TelephonyManager.NETWORK_TYPE_GPRS
						|| nSubType == TelephonyManager.NETWORK_TYPE_EDGE
						|| nSubType == TelephonyManager.NETWORK_TYPE_CDMA
						|| nSubType == TelephonyManager.NETWORK_TYPE_1xRTT
						&& !telephonyManager.isNetworkRoaming()) {
					netType = 2;
				} else if(nSubType == TelephonyProtoEnums.NETWORK_TYPE_UNKNOWN){
					netType = 0;
				}
			}
		}
		return netType;
    }
    
    
	/**
	 * volte增强功能开关
	 * @param isEnabled
	 * @return
	 */
    public static boolean setEnhanced4gLteModeSetting(boolean isEnabled) {
    	LogUtils.print("enter into isAdvancedCallingSettingEnabled  isEnabled:"+isEnabled);
    	List<SubscriptionInfo> subInfos = SubscriptionManager.from(mContext).getActiveSubscriptionInfoList();
    	LogUtils.print( "subInfos size:"+subInfos.size());
    	if(subInfos.size() == 0){
    		LogUtils.print( "SubscriptionInfo sir == null");
        	return false;
    	}
    	int subId = -1;
    	for(SubscriptionInfo subInfo : subInfos){
    		subId = subInfo.getSubscriptionId();
    		LogUtils.print( "subId:"+subId);
      	    
    	}
    	if (!SubscriptionManager.isValidSubscriptionId(subId)) {
			return false;
		}
    	final ImsMmTelManager imsMmTelManager = ImsMmTelManager.createForSubscriptionId(subId);
    	if (imsMmTelManager == null) {
    		return false;
    	}
    	try {
    		imsMmTelManager.setAdvancedCallingSettingEnabled(isEnabled);
			imsMmTelManager.isAdvancedCallingSettingEnabled();
    	} catch (IllegalArgumentException exception) {
    		return false;
    	}
    	return true;
    }
    /**
     * 是否volte增强功能打开
     */
    public static boolean isAdvancedCallingSettingEnabled() {
    	boolean ret= false;
    	int subId = -1;
    	LogUtils.print("enter into isAdvancedCallingSettingEnabled ");
    	try {
    		List<SubscriptionInfo> subInfos = SubscriptionManager.from(mContext).getActiveSubscriptionInfoList();
        	LogUtils.print( "subInfos size:"+subInfos.size());
        	if(subInfos.size() == 0){
        		LogUtils.print( "SubscriptionInfo sir == null");
            	return false;
        	}
        	
        	for(SubscriptionInfo subInfo : subInfos){
        		subId = subInfo.getSubscriptionId();
        		LogUtils.print( "subId:"+subId);
          	    
        	}
        	if (!SubscriptionManager.isValidSubscriptionId(subId)) {
    			return false;
    		}

    		final ImsMmTelManager imsMmTelManager = ImsMmTelManager.createForSubscriptionId(subId);
    		ret = imsMmTelManager.isAdvancedCallingSettingEnabled();
    		LogUtils.print(" isAdvancedCallingSettingEnabled ret:"+ret);
    	} catch (IllegalArgumentException exception) {
    		LogUtils.print("fail to get VoLte settings. subId=" + subId, exception);
    	}
    	
    	return ret;
    }
    
    
     /**
      * 是否自动选择网络
      */
    public static boolean isAutoSelectNetwork(){
    	boolean ret = false;
    	TelephonyManager telephonyManager = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
    	int mode = telephonyManager.getNetworkSelectionMode();

    	if(mode == TelephonyManager.NETWORK_SELECTION_MODE_AUTO){
    		ret = true;
    	}
    	return  ret ;
    }
    
    /**
     * 设置自动选择网络
     */
    
    public static boolean setAutoSelectNetwork(){
    	boolean ret = false;
    	LogUtils.print("enter into setAutoSelectNetwork");
    	TelephonyManager telephonyManager = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
    	LogUtils.print("enter into setNetworkSelectionModeAutomatic +");
    	telephonyManager.setNetworkSelectionModeAutomatic();
    	LogUtils.print("enter into setNetworkSelectionModeAutomatic -");
    	final int mode = telephonyManager.getNetworkSelectionMode();
    	LogUtils.print("enter into setAutoSelectNetwork mode:"+mode);
    	if(mode == TelephonyManager.NETWORK_SELECTION_MODE_AUTO){
    		ret = true;
    	}
    	return ret;
    }
}