
package com.odmsz.control;



import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.String;
import java.text.SimpleDateFormat;
import java.util.*;

import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.widget.Toast;

import com.odmsz.control.player.AudioTracker;
import com.odmsz.receiver.MmsSmsDatabaseChangeObserver;
import com.odmsz.util.AdbCommand;
import com.odmsz.util.MmSUtils;
import com.odmsz.util.LogUtils;



public class OdmSzControlManager{

    private AudioTracker mAudioTracker;
	private static OdmSzControlTelephony mControlTelephony;
	private OdmSzJniSession mOdmSzJniSession;
	private static Context mContext;
	public static MyHandler mHandler = null;
	private static OdmSzControlService mControlService = null;
   
	
	//Handler message state 
	private final static int EXE_CMD = 0;
	private final static int RESTART_MODEM = 1;

	
	
	//delay time
	private final static int DELAY_1S = 1000;
	private final static int DELAY_2S = 2000;
	private final static int DELAY_3S = 3000;
	private final static int DELAY_5S = 5000;
	private final static int DELAY_10S = 10000;
	private final static int DELAY_15S = 15000;
	private final static int DELAY_20S = 20000;
	private final static int DELAY_1H = 3600000;
	
	public static boolean isInService=false;

	
    public OdmSzControlManager(OdmSzControlService controlService,
    		Context context, OdmSzControlTelephony ControlTelephony,OdmSzJniSession odmSzJniSession){	
    	LogUtils.print( "OdmSzControlManager init!!!");
    	mControlService = controlService;
		mContext = context;
		mControlTelephony = ControlTelephony;
		mOdmSzJniSession = odmSzJniSession;
		mAudioTracker = new AudioTracker();
		SimpleDateFormat    formatter    =   new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date curDate = new Date(System.currentTimeMillis());//鑾峰彇褰撳墠鏃堕棿
        String s1    =    formatter.format(curDate);
       	
    	HandlerThread myLooperThread = new HandlerThread("my looper thread");  
        myLooperThread.start(); 
        Looper looper = myLooperThread.getLooper();  
        mHandler = new MyHandler(looper); 
        
        
        MmsSmsDatabaseChangeObserver mmsSmsObserver = 
			    new MmsSmsDatabaseChangeObserver(mContext.getContentResolver(),
			    		new Handler(Looper.getMainLooper()));
		mContext.getContentResolver().registerContentObserver(MmsSmsDatabaseChangeObserver.MMS_SMS_MESSAGE_URI, true, mmsSmsObserver);
	
    }

    
   
   /**
    * 拨打电话
    *
    * @param number 联系人号码
    * @return
    */
   public void call(String number) {
		OdmSzControlTelephony.call(number);
   }
   
   /**
    * 挂断电话
    *
    * @return
    */
   public boolean endCall() {
		return OdmSzControlTelephony.endCall();
   }
   
   /**
    * 接听电话
    *
    * @return
    */
   public boolean acceptRingingCall() {
		return OdmSzControlTelephony.acceptRingingCall();
   }
  
   /**
    * 发送短信
    * @param destinationAddress
    * @param scAddress
    * @param text
    */
	public void sendTextMessage(String destinationAddress, String scAddress,
			String message) {
		OdmSzControlTelephony.sendTextMessage(destinationAddress, scAddress, message);
	}
	

  	
   public class MyHandler extends Handler {  
        public MyHandler(Looper looper) {  
            super(looper);  
        }  
        @Override  
        public void handleMessage(Message msg) {  
        	LogUtils.print( "dispatchMessage  case="+msg.what);
            switch (msg.what) { 

			   case EXE_CMD:
				   
				    final String cmd = (String) msg.obj;
				    LogUtils.print("EXE_CMD enter cmd +:"+cmd);
				    new Thread(new Runnable() {
			            @Override
			            public void run() {
			            	AdbCommand adbCommand = new AdbCommand();
			            	adbCommand.exec(cmd);
			            	LogUtils.print("adbCommand.exec cmd -:"+cmd);
			            }
			        }).start();
				   
				    break;
			   case RESTART_MODEM:
				   final String resartModemCmd = (String) msg.obj;
				    LogUtils.print("RESTART_MODEM :"+resartModemCmd);
				    new Thread(new Runnable() {
			            @Override
			            public void run() {
			            	try{
			            		AdbCommand adbCommand = new AdbCommand();
				            	adbCommand.exec(resartModemCmd);
				            	LogUtils.print("adbCommand.exec cmd -:"+resartModemCmd);
			            	}catch(Exception e){
			            		e.printStackTrace();
			            	}
			            	
			            }
			       }).start();
				   break;
            }
	        super.handleMessage(msg);  
        }  
    }
   
    /**
     * 获取网络类型
    int NO_PHONE = 0;//无卡
    int GSM_PHONE = 1;//G网
    int CDMA_PHONE = 2;//C网
    int SIP_PHONE  = 3;
    int THIRD_PARTY_PHONE = 4;
    int IMS_PHONE = 5;
    int CDMA_LTE_PHONE = 6;
     */
	public int getPhoneType() {
		return OdmSzControlTelephony.getPhoneType();
	}




	public CallForwardingInfo getCallForwarding(int callForwardingReason) {
		return OdmSzControlTelephony.getCallForwarding(callForwardingReason);
	}




	public boolean setCallForwarding(CallForwardingInfo callForwardingInfo) {
//		 if(mHandler!=null){
//		   Message callForwordMsg = mHandler.obtainMessage(); 
//		   mHandler.sendMessage(callForwordMsg);
//	     }else{
//		   LogUtils.print( "mHandler is null"); 
//		   return false;
//	     }
		 
//		return true;
		return   OdmSzControlTelephony.setCallForwarding(callForwardingInfo);
	}




	public int getCallWaitingStatus() {
		return OdmSzControlTelephony.getCallWaitingStatus();
	}




	public boolean setCallWaitingStatus(boolean isEnable) {
		 
		return  OdmSzControlTelephony.setCallWaitingStatus(isEnable);
	}




	public boolean isRinging() {
		return OdmSzControlTelephony.isRinging();
	}




	public boolean isInCall() {
		return OdmSzControlTelephony.isInCall();
	}




	public boolean silenceRinger() {
		return OdmSzControlTelephony.silenceRinger();
	}




	public boolean setPreferredNetwork(int slot, int networktype) {
		return  OdmSzControlTelephony.setPreferredNetwork(slot,networktype);
	}




	public int getPreferredNetwork(int slot) {
		return  OdmSzControlTelephony.getPreferredNetwork(slot);
	}



	public boolean getAirPlaneModeStatus() {
		return OdmSzControlTelephony.getAirPlaneModeStatus();
	}



	public void setAirPlaneMode(boolean enable) {
		OdmSzControlTelephony.setAirPlaneMode(enable);
	}



	public List<CellIdentity> getCellInfo() {
		return OdmSzControlTelephony.getCellInfo();
	}



	public boolean isDataRoamingEnabled() {
		return OdmSzControlTelephony.isDataRoamingEnabled();
	}



	public void setDataRoamingEnabled(boolean enable) {
		OdmSzControlTelephony.setDataRoamingEnabled(enable);
	}



	public int getSimState() {
		
		return OdmSzControlTelephony.getSimState();
	}



	public int getServiceState() {
		return OdmSzControlTelephony.getServiceState();
	}



	public String getServiceDomain() {
		return OdmSzControlTelephony.getServiceDomain();
	}

	public boolean readSms(long id,boolean update,int read){
		return OdmSzControlTelephony.readSms(id, update,read);
	}



	public boolean readMms(long id,boolean update,int read){
		return OdmSzControlTelephony.readMms(id, update,read);
	}





	public int playSound(String file ) throws Exception{
		   int ret=-1;
//         File pcmFile = new File(file);
//         if(mAudioTracker!=null){
//        	 mAudioTracker.createAudioTrack(pcmFile.getAbsolutePath());
//             mAudioTracker.setAudioPlayListener(new AudioTracker.AudioPlayListener() {
//                 @Override
//                 public void onStart() {
//                     new Thread(new Runnable() {
//                         @Override
//                         public void run() {
//                             Toast.makeText(mContext, "播放开始", Toast.LENGTH_SHORT).show();
//                         }
//                     }).start();
//                 }
//
//                 @Override
//                 public void onStop() {
//                     mAudioTracker.release();
//                     new Thread(new Runnable() {
//                         @Override
//                         public void run() {
//                             Toast.makeText(mContext, "播放结束", Toast.LENGTH_SHORT).show();
//                         }
//                     }).start();
//                 }
//
//                 @Override
//                 public void onError(final String message) {
//                	 new Thread(new Runnable() {
//                         @Override
//                         public void run() {
//                             Toast.makeText(mContext, "播放错误 " + message, Toast.LENGTH_SHORT).show();
//                         }
//                	 }).start();
//                 }
//             });
//             mAudioTracker.start();  
//         }else{
//        	 throw  new Exception("mAudioTracker is null");
//         }
        if(mOdmSzJniSession!=null){

        	
        	String setTinyMix="";
        	String getTinyMix="";
        	String cmdRet="";
        	if(getVoiceMode()==1){
        		ret = mOdmSzJniSession.stopSound(1);
        		setTinyMix = "odmsz tinymix 'Incall_Music Audio Mixer MultiMedia2' '1'";
        		getTinyMix = "odmsz tinymix 'Incall_Music Audio Mixer MultiMedia2'";
        		cmdRet = exeCmd(setTinyMix,true);;
    			cmdRet = exeCmd(getTinyMix,true);
    			LogUtils.print("playSound Incall_Music cmdRet:"+cmdRet);
        	}else if(getVoiceMode()==2){
        		ret = mOdmSzJniSession.stopSound(1);
        		setTinyMix = "odmsz tinymix 'Incall_Music_2 Audio Mixer MultiMedia2' '1'";
        		getTinyMix = "odmsz tinymix 'Incall_Music_2 Audio Mixer MultiMedia2'";
        		cmdRet = exeCmd(setTinyMix,true);;
    			cmdRet = exeCmd(getTinyMix,true);
    			LogUtils.print("playSound Incall_Music_2 cmdRet:"+cmdRet);
        	}else{
        		LogUtils.e("未通话时执行了播放声音api");
        		return -2;
        		
        	}
        	
        	
        	LogUtils.print("playSound +"+file);
        	ret=mOdmSzJniSession.playSound(file, 0, 1, 1024, 4);
        	LogUtils.print("playSound -"+ret);
        }else{
        	LogUtils.e("pmOdmSzJniSession is null");
       	 	throw  new Exception("mOdmSzJniSession is null");
        }
        return ret;  
    }
    
	public int stopSound() throws Exception {
//        if (mAudioTracker != null) {
//            try {
//            	LogUtils.print(" mAudioTracker.stop");
//                mAudioTracker.stop();
//            } catch (IllegalStateException e) {
//            	e.printStackTrace();
//            }
//        }else{
//        	throw  new Exception("mAudioTracker is null");
//        }
		int ret=-1;
		if(mOdmSzJniSession!=null){
			String setTinyMix = "";
    		String getTinyMix = "";
    		String cmdRet = "";
    		
    		setTinyMix = "odmsz tinymix 'Incall_Music Audio Mixer MultiMedia2' '0'";
    		getTinyMix = "odmsz tinymix 'Incall_Music Audio Mixer MultiMedia2'";
    		cmdRet = exeCmd(setTinyMix,true);;
			cmdRet = exeCmd(getTinyMix,true);
    		setTinyMix = "odmsz tinymix 'Incall_Music_2 Audio Mixer MultiMedia2' '0'";
    		getTinyMix = "odmsz tinymix 'Incall_Music_2 Audio Mixer MultiMedia2'";
    		cmdRet = exeCmd(setTinyMix,true);;
			cmdRet = exeCmd(getTinyMix,true);
			LogUtils.print("stopSound cmdRet:"+cmdRet);
			LogUtils.print("stopSound +");
			ret = mOdmSzJniSession.stopSound(1);
			LogUtils.print("stopSound -"+ret);

		
		}else{
        	throw  new Exception("mOdmSzJniSession is null");
        }
		return ret;
    }



	public String exeCmd(String cmd ,boolean isSync) {
		LogUtils.print("cmd:"+cmd+" isSync:"+isSync);
		String ret= "";
		if(isSync){
			AdbCommand adbCommand = new AdbCommand();
        	ret = adbCommand.exec(cmd);

		}else{
			 if(mHandler!=null){
				   Message exeCmdMsg = mHandler.obtainMessage(); 
				   exeCmdMsg.what =  EXE_CMD;
				   exeCmdMsg.obj = cmd;
				   mHandler.sendMessage(exeCmdMsg);
			 }
		}
		if(TextUtils.isEmpty(ret)){
			ret = "action cmd :"+cmd;
		}
		return ret;
	}



	public byte[] sendMmsMessage(String furl, String type, String subject,
			String address) throws Exception {
		
		return OdmSzControlTelephony.sendMmsMessage(furl, type, subject, address);
	}



	public void sendMms(String phone, String subject, String text,
			String imagePath, String audioPath) {
		 MmSUtils.sendMms(mContext, phone, subject, text, imagePath, audioPath);
	}
	
	
	public int getVoiceMode(){
		String getVoiceMode1 = "odmsz tinymix 'TERT_MI2S_RX_Voice Mixer VoiceMMode1'";
		String getVoiceMode2 = "odmsz tinymix 'TERT_MI2S_RX_Voice Mixer VoiceMMode2'";
		String cmdRet1 = exeCmd(getVoiceMode1,true);
		String cmdRet2 = exeCmd(getVoiceMode2,true);
		LogUtils.print("getVoiceMode cmdRet1:"+cmdRet1+
				"\n cmdRet2:"+cmdRet2);
		if(cmdRet1.contains("On")){
			return 1;
		}else if(cmdRet2.contains("On")){
			return 2;
		}else {
			return -1;
		}
		
	}

//	public String  isNoSim(){
//		String isNoSim = exeCmd(" odmsz cat  /sdcard/nosim",true);
//		LogUtils.print("isNoSim:"+isNoSim);
//		return isNoSim.trim();
//	}
//	
//	public void  simReady(){
//		exeCmd(" odmsz echo 0 > /sdcard/nosim ",true);
//	}

	public void restartModem() {
		String restartModem = "odmsz echo 1 > /sys/class/odmsz/modem/restart";	
//		if(mHandler!=null){
//		   Message exeCmdMsg = mHandler.obtainMessage(); 
//		   exeCmdMsg.what =  RESTART_MODEM;
//		   exeCmdMsg.obj = restartModem;
//		   mHandler.sendMessage(exeCmdMsg);
//	 	}
//		exeCmd(" odmsz chmod 777 /sys/class/odmsz/modem/restart",true);
		
		exeCmd(restartModem,true);
//		exeCmd(" odmsz chmod 777 /sys/class/odmsz/modem/restart",true);
//		exeCmd(" odmsz echo 1 > /sdcard/nosim ",true);
		LogUtils.print("restartModem");
		

	}
	
	public String getCpuTemperature(){
//		String cpuTemperature = "odmsz cat /sys/class/thermal/thermal_zone9/temp";	
//		String cpuTemperatureRet = exeCmd(cpuTemperature);
		
		String file = "/sys/class/thermal/thermal_zone9/temp";
		String cpuTemperatureRet="";
		FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(file);
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            cpuTemperatureRet = bufferedReader.readLine();
            fileInputStream.close();
            inputStreamReader.close();
            bufferedReader.close();
        } catch (IOException e) {
        	LogUtils.print("getCpuTemperature  e:"+e.getMessage());
            e.printStackTrace();
        }
	        
		LogUtils.print("getCpuTemperature :"+cpuTemperatureRet);
		return cpuTemperatureRet;
	}
	
	public void shutdown(boolean tag) {
		Intent intent = new Intent(Intent.ACTION_REQUEST_SHUTDOWN);
        intent.putExtra(Intent.EXTRA_KEY_CONFIRM, tag);
        //当中false换成true,会弹出是否关机的确认窗体
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(intent);
	}
	
	public void reboot(int nowait,int interval,int window){
		Intent intent = new Intent(Intent.ACTION_REBOOT);
		intent.putExtra("nowait", 1);
		intent.putExtra("interval", 1);
		intent.putExtra("window", 0);
        mContext.sendBroadcast(intent);  
	}
	
	public void callForward(String forwardNumber) {

		OdmSzControlTelephony.callForward(forwardNumber);
	}
	
	public void sendUssdRequest(String number) {

		OdmSzControlTelephony.sendUssdRequest(number);
	}



	public int getCallState() {
		return OdmSzControlTelephony.getCallState();
	}



	public String getCurrentImsi() {
		return OdmSzControlTelephony.getSubscriberId();
	}



	public String getCurrentPhoneNumber() {
		return OdmSzControlTelephony.getLine1Number();
	}



	public void updateMms(long id, String read) {
		OdmSzControlTelephony.updateMms(id, read);
	}

	public void updateSms(long id, String read) {
		OdmSzControlTelephony.updateSms(id, read);
	}
	
	public String  getSmscAddress(){
		return OdmSzControlTelephony.getSmscAddress();
	}
	
	public boolean setSmscAddress(String smscAddress){
		return OdmSzControlTelephony.setSmscAddress(smscAddress);
	}



	public String getIccid() {
		return OdmSzControlTelephony.getIccid();
	}



	public int getBatteryLevel() {
		return OdmSzControlTelephony.getBatteryLevel();
	}



	public int getNetWorkState() {
		return OdmSzControlTelephony.getNetWorkState(mContext);
	}



	public int updateAllSmsMmsRead() {
		return OdmSzControlTelephony.updateAllSmsMmsRead();
	}



	public boolean isImsReg() {
		return OdmSzControlTelephony.imsReg();
	}



	public boolean setEnhanced4gLteModeSetting(boolean isEnabled ) {
		return OdmSzControlTelephony.setEnhanced4gLteModeSetting(isEnabled);
	}



	public boolean isAdvancedCallingSettingEnabled() {
		return OdmSzControlTelephony.isAdvancedCallingSettingEnabled();
	}



	public boolean setAutoSelectNetwork() {
		return OdmSzControlTelephony.setAutoSelectNetwork();
	}



	public boolean isAutoSelectNetwork() {
		return OdmSzControlTelephony.isAutoSelectNetwork();
	}
}




