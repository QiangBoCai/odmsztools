
package com.odmsz.control;

import com.odmsz.util.LogUtils;

public class OdmSzJniSession {
	
	/**
	 * Load libtinyplay.so file
	 * */
    static
    {
        try
        {
            System.loadLibrary("tinyplay_jni");

        }
        catch(UnsatisfiedLinkError e)
        {
        	LogUtils.e("Cannot load library:\n " +e.toString() );
        }
    }
    /**
     * 停止播放
     * stream_close
     * */
    public native int stopSound(int sig) ;
    /**
     * sample_is_playable
     * unsigned int device = 1; //default 1
     * unsigned int card = 0;//default 0
    unsigned int period_size = 1024;default 1024
    unsigned int period_count = 4;//default4 
    Usage: %s file.wav [-D card] [-d device] [-p period_size]"
                " [-n n_periods] \n
    adb shell tinyplay /sdcard/audio_L_R_test.wav -D 0 -d 1
     * */
    public native int playSound(String file,int card,
    		 int device,int periodSize,
             int periodCount);
    
}

