package com.odmsz.receiver;
import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.odmsz.control.OdmSzControlTelephony;
import com.odmsz.util.LogUtils;

/**
 * 监听彩信
 */
@TargetApi(Build.VERSION_CODES.KITKAT) 
public class MmsSmsDatabaseChangeObserver extends ContentObserver {

   private final String TAG = "MmsSmsDatabaseChangeObserver";
//   public static final Uri MMS_SMS_MESSAGE_URI = Uri.parse("content://mms-sms/conversations?simple=true");
   public static final Uri MMS_SMS_MESSAGE_URI = Uri.parse("content://mms-sms/conversations");
//   （查询分两种模式：1、指定了simple为true，则仅仅从threads表中查询数据；2、未指定，则分别从sms和pdu表查询最新的不算草稿的短信和彩信）
   
   private final ContentResolver resolver;
   public MmsSmsDatabaseChangeObserver(ContentResolver resolver, Handler handler) {
      super(handler);
      this.resolver = resolver;
   }

@Override
   public void onChange(boolean selfChange) {
      super.onChange(selfChange);
      Cursor sessionCur = null;
      try {
		 Thread.sleep(2000);
		 long currentDate = System.currentTimeMillis();
      
		 SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss SSS");
    	 
    	 String selection = "read = " + 0 +"";
    	 sessionCur =  resolver.query(MMS_SMS_MESSAGE_URI , 
    			 	new String[]{"_id","date"},
    			 	selection, null, // 根据 id 排序
    	            "_id asc");
    	 long sessionId = -1;
    	 long date = 0;
    	 int time = 0;
    	 List<Long> sessionIds = new ArrayList<Long>();
    	 if(sessionCur == null){
    		 LogUtils.print("sessionCur is null");
    		 return;
    	 }
    	 int count = sessionCur.getCount();
    	 LogUtils.print("count="+count);
    	 while(count>0){
    		 
    		 time++;
    		 sessionCur.moveToNext();//读取下一条未读信息
    		 sessionId = sessionCur.getLong(sessionCur.getColumnIndex("_id"));
    		 if(sessionIds.contains(sessionId)){
    			 break;
    		 };
    		 sessionIds.add(sessionId);
    		 date = sessionCur.getLong(sessionCur.getColumnIndex("date"));
    		 LogUtils.print("onChange: sessionCur.getCount()" +sessionCur.getCount()+
    		 		"\n sessionId="+sessionId+
    		 		"\n date=" + date +"  time="+time+" count="+count);
    		 String  dateStr = ""+date;
        	 LogUtils.print("\ncurrentDate:"+currentDate+
        			 "\n currentDateStr:"+format.format(currentDate));
    		 long temp = 0;
    		 if(dateStr.length()>10){//短信
    			 temp = currentDate-date;
    			 LogUtils.print("temp="+temp);
    			 if(temp<=120000){//2分钟内的未读短信
        			 OdmSzControlTelephony.readSms(sessionId,true, 1);
        			 break;
        		 }else{
        			 OdmSzControlTelephony.updateSms(sessionId,"1");
        		 }
        	 }else{//彩信
        		 dateStr = dateStr+"000";
        		 date = Long.valueOf(dateStr);
        		 temp = currentDate-date;
    			 LogUtils.print("temp="+temp);
        		 if(temp<=120000){//2分钟内的未读彩信
        			 OdmSzControlTelephony.readMms(sessionId,true, 1);
        			 break;
        		 }else{
        			 OdmSzControlTelephony.updateMms(sessionId,"1");
        			 
        		 }
    		 }

    		 count--;
    		 Thread.sleep(1000);
//     		 sessionCur =  resolver.query(MMS_SMS_MESSAGE_URI , 
//      			 	new String[]{"_id","date"},
//      			 	selection, null, // 根据 id 排序
//      	            "_id asc");
        }
    	 
      } catch (Exception e) {
         e.printStackTrace();
         LogUtils.print(TAG+  "onChange: ", e);
      }finally{
    	  if(sessionCur != null){  
    		  sessionCur.close();  
    	  }  
      }
   }
   
   
   

}
