
package com.odmsz.receiver;


import android.app.Activity;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;  
import android.content.Intent;
import android.os.BatteryManager;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.widget.Toast;

import com.odmsz.control.OdmSzControlService;
import com.odmsz.control.OdmSzInCallServiceImpl;
import com.odmsz.control.PreciseCallState;
import com.odmsz.util.LogUtils;

public class OdmSzControlReceiver extends BroadcastReceiver{

    
    public static final String ACTION_BOOT = "android.intent.action.BOOT_COMPLETED";
    public static final String ACTION_SHUTDOWN="android.intent.action.ACTION_SHUTDOWN";  
    public static final String ACTION_AIRPLANE_MODE_CHANGED = "android.intent.action.AIRPLANE_MODE";
    
    public static final String ACTION_SMS_RECEIVED= "android.provider.Telephony.SMS_RECEIVED";
    public static final String ACTION_SEND_SMS= "ACTION_SEND_SMS";
    public static final String ACTION_DELIVERY_SMS= "ACTION_DELIVERY_SMS";
    public static final String ODMSZ_SMS_RECEIVED = "android.intent.action.ODMSZ_SMS_RECEIVED";
    public static final String ODMSZ_CALL_RECEIVED = "android.intent.action.ODMSZ_CALL_RECEIVED";
    public static final String ODMSZ_MMS_RECEIVED = "android.intent.action.ODMSZ_MMS_RECEIVED";
    public static final String ODMSZ_MMS_SENT_ACTION =  "android.intent.action.ODMSZ_MMS_SENT";
    public static final String ODMSZ_USSD_SENT_ACTION =  "android.intent.action.ODMSZ_USSD_SENT";
//    public static final String ACTION_PRECISE_CALL_STATE = "android.intent.action.PRECISE_CALL_STATE";
	private PreciseCallState  preciseCallState= new PreciseCallState() ; 
    private static String lastIntentStr = "";
    private static long lastBroadCastTime = 0;
    /**
     * Device call state: No activity.
     * 空闲态(没有通话活动)
     */
    public static final int CALL_STATE_IDLE = 0;
    /**
     * Device call state: Ringing. A new call arrived and is
     *  ringing or waiting. In the latter case, another call is
     *  already active.
     *  包括响铃、第三方来电等待
     */
    public static final int CALL_STATE_RINGING = 1;
    /**
     * Device call state: Off-hook. At least one call exists
     * that is dialing, active, or on hold, and no calls are ringing
     * or waiting.
     * 摘机（接听）：包括dialing拨号中、active接通、hold挂起等
     */
    public static final int CALL_STATE_OFFHOOK = 2;
    
	private Context mContext=null;
    
    @Override  
    public void onReceive(final Context context, Intent intent){	
    	mContext=context;
    	String receiveAction = intent.getAction();
    	LogUtils.print( "receiveAction="+receiveAction);
    	if (ACTION_BOOT.equals(receiveAction)){    		
    		if (!OdmSzControlService.mServiceOn){
    			
    			//开机广播后都自动启动服务startService
				Intent intent1 = new Intent(OdmSzControlService.ACTION)
						.setPackage("com.odmsz.control");
				context.startService(intent1);
			}
//    		if(OdmSzInCallServiceImpl.sInstance==null){
//        		Intent intent2 = new Intent(OdmSzInCallServiceImpl.ACTION)
//    			.setPackage("com.odmsz.control");
//    			context.startService(intent2);
//    		}

			return;
//    	}else if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())){
//    		int temperature = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
//    		LogUtils.print( "onReceive  ACTION_BATTERY_CHANGED temperature "+temperature);
		}else if(ACTION_AIRPLANE_MODE_CHANGED.equals(intent.getAction())){
   		   	LogUtils.print( "onReceive  ACTION_AIRPLANE_MODE_CHANGED ");
		}else if (ACTION_SMS_RECEIVED.equals(intent.getAction())){//接收短信
			LogUtils.print( "onReceive  ACTION_SMS_RECEIVED ");
		
			Bundle bundle = intent.getExtras();
	        Object[] pdus = (Object[]) bundle.get("pdus");
	        SmsMessage[] msgs = new SmsMessage[pdus.length];
	        for (int i = 0; i < pdus.length; i++) {
	            msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
	        }
	        //发送广播给上层APP
	    	Intent appIntent = new Intent();
	    	StringBuilder strb = new StringBuilder();
	    	String phone ="";
	    	String content = "";
	    	String centerAddress = "";
	        for (SmsMessage msg : msgs) {
	        	phone = msg.getDisplayOriginatingAddress();
	        	centerAddress = msg.getServiceCenterAddress();
	            strb.append(msg.getDisplayMessageBody());

	        }
	        content = strb.toString();
            appIntent.putExtra("phone",phone);
            appIntent.putExtra("content",content);
            appIntent.putExtra("centerAddress",centerAddress);
	        appIntent.setAction(ODMSZ_SMS_RECEIVED);
//	    	mContext.sendBroadcast(appIntent);
	    	LogUtils.print("phone:"+phone+"\ncontent:"+content+"\ncenterAdress:"+centerAddress);
		
		}else if (ACTION_SEND_SMS.equals(intent.getAction())){//发送出短信
       		LogUtils.print( "onReceive  ACTION_SENT_SMS ");
       		switch (getResultCode()) {
       			case Activity.RESULT_OK:
       				LogUtils.print( "短信下发成功");
       				break;
	            case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
	            	break;
	            case SmsManager.RESULT_ERROR_NO_SERVICE:
					break;
	            case SmsManager.RESULT_ERROR_RADIO_OFF:
	            	break;
	            case SmsManager.RESULT_ERROR_NULL_PDU:
	            	break;
	            }
       	}else if (ACTION_DELIVERY_SMS.equals(intent.getAction())){//短信到达,实际场景用不到
       		LogUtils.print( "onReceive  ACTION_DELIVERY_SMS ");
       		switch(getResultCode()){
       		case Activity.RESULT_OK:
				LogUtils.print(" 短信成功到达");
				break;
			case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
				LogUtils.print("[Delivery]SMS Delivery:RESULT_ERROR_GENERIC_FAILURE!");
				break;
			case SmsManager.RESULT_ERROR_NO_SERVICE:
				LogUtils.print("[Delivery]SMS Delivery:RESULT_ERROR_NO_SERVICE!");
				break;
			case SmsManager.RESULT_ERROR_NULL_PDU:
				LogUtils.print("[Delivery]SMS Delivery:RESULT_ERROR_NULL_PDU!");
				break;
			case SmsManager.RESULT_ERROR_RADIO_OFF:
				LogUtils.print("[Delivery]SMS Delivery:RESULT_ERROR_RADIO_OFF!");
				break;
       		}
       	}else if(intent.getAction().equals(Intent.ACTION_NEW_OUTGOING_CALL)){//去电
            String phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
            LogUtils.print("onReceive ACTION_NEW_OUTGOING_CALL call OUT:" + phoneNumber); 
            if(TextUtils.isEmpty(phoneNumber)){
            	LogUtils.e("onReceive ACTION_NEW_OUTGOING_CALL phoneNumber isEmpty"); 
            	return;
            }
       	}else if (intent.getAction().equals(TelephonyManager.ACTION_PHONE_STATE_CHANGED)){
       		TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
       		tm.listen(listener, 
       			PhoneStateListener.LISTEN_PRECISE_CALL_STATE|PhoneStateListener.LISTEN_CALL_STATE);
        }
    }
    
    
    
    private PhoneStateListener listener=new PhoneStateListener(){
		/** Call state is not valid (Not received a call state). */
		public static final int PRECISE_CALL_STATE_NOT_VALID =      -1;
		/** Call state: No activity. */
		public static final int PRECISE_CALL_STATE_IDLE =           0;
	
		/** Call state: Active. */
		public static final int PRECISE_CALL_STATE_ACTIVE =         1;
		/** Call state: On hold. */
		public static final int PRECISE_CALL_STATE_HOLDING =        2;
		/** Call state: Dialing. */
		public static final int PRECISE_CALL_STATE_DIALING =        3;
		/** Call state: Alerting. */
		public static final int PRECISE_CALL_STATE_ALERTING =       4;
		/** Call state: Incoming. */
		public static final int PRECISE_CALL_STATE_INCOMING =       5;
		/** Call state: Waiting. */
		public static final int PRECISE_CALL_STATE_WAITING =        6;
		/** Call state: Disconnected. */
		public static final int PRECISE_CALL_STATE_DISCONNECTED =   7;
		/** Call state: Disconnecting. */
		public static final int PRECISE_CALL_STATE_DISCONNECTING =  8;
		
	    /**
	     * Device call state: No activity.
	     */
	    public static final int CALL_STATE_IDLE = 0;
	    /**
	     * Device call state: Ringing. A new call arrived and is
	     *  ringing or waiting. In the latter case, another call is
	     *  already active.
	     */
	    public static final int CALL_STATE_RINGING = 1;
	    /**
	     * Device call state: Off-hook. At least one call exists
	     * that is dialing, active, or on hold, and no calls are ringing
	     * or waiting.
	     */
	    public static final int CALL_STATE_OFFHOOK = 2;
	    
	    

		@Override
		public void onPreciseCallStateChanged( android.telephony.PreciseCallState callState){
//			LogUtils.print("onPreciseCallStateChanged:"+callState.toString());
//			preciseCallState = callState;
//			 PreciseCallState( int ringingCall,
//                     int foregroundCall,
//                     int backgroundCall,
//                     int disconnectCause,
//                     int preciseDisconnectCause) 
//                     
			preciseCallState = new PreciseCallState(callState.getRingingCallState(),
					callState.getForegroundCallState(),
					callState.getBackgroundCallState(),
					callState.getDisconnectCause(),
					callState.getPreciseDisconnectCause());
		}
    	
    	
	   @Override
	   public void onCallStateChanged(int state, final String number) {
	     super.onCallStateChanged(state, number);
	     
	     LogUtils.print("incomingNumber:"+number+"callState:"+state
	    		 +"\n preciseCallState:"+preciseCallState.toString());
	     
	     //发送广播给上层APP
	     Intent currentIntent = new Intent();
	     currentIntent.putExtra("number",number);
        
	     switch(state){
	       case CALL_STATE_IDLE:
	    	   LogUtils.print("待机状态");
	    	   currentIntent.putExtra("state",TelephonyManager.CALL_STATE_IDLE);
	    	   currentIntent.putExtra("preciseCallState", preciseCallState);
	    	   break;
	       case CALL_STATE_RINGING:
	    	   //输出来电号码
	    	   LogUtils.print("响铃状态");
	    	   currentIntent.putExtra("state",TelephonyManager.CALL_STATE_RINGING);
	    	   currentIntent.putExtra("preciseCallState", preciseCallState);
		       break;
	       case CALL_STATE_OFFHOOK:
	    	   currentIntent.putExtra("state",TelephonyManager.CALL_STATE_OFFHOOK);
	    	   LogUtils.print("通话状态");
	    	   currentIntent.putExtra("preciseCallState", preciseCallState);
	    	   break;

	     }
	     currentIntent.setAction(ODMSZ_CALL_RECEIVED);
	     
	     String currentIntentStr = ""+state+preciseCallState.toString();
	     //去重
	     long currentTime = System.currentTimeMillis();
	     long temp = currentTime - lastBroadCastTime;
	     if((!currentIntentStr.equals(lastIntentStr))&&temp>=100){
	    	 LogUtils.print("sendBroadcast  ODMSZ_CALL_RECEIVED");
	    	 currentIntent.putExtra("time",currentTime);
	    	 mContext.sendBroadcast(currentIntent);
	    	 lastBroadCastTime=currentTime;
	     }
	     lastIntentStr=currentIntentStr;
	     
	   }
	 };
}  